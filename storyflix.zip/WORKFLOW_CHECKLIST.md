# Rebuild & Consolidation Workflow Checklist (SimplifiedPipeline Architecture)

- [x] **Step 1: Skill & Protocol Initialization**
  - Verify `@google/genai` SDK standards and UI/UX layout directives.
  - Establish `WORKFLOW_CHECKLIST.md` tracking.

- [x] **Step 2: Full-Width UI Space & Visual Container Cleanup**
  - Expanded `SimplifiedPipelineDemo.tsx` viewports to fill container bounds (removed restrictive nested `max-w-5xl` bottlenecks).
  - Streamlined Phase 1-5 header panels, tab bar, and workspace viewports.

- [x] **Step 3: Multi-Scene Selection & Matrix-to-Bible Flow**
  - Enabled seamless multi-scene selection from Phase 3 Idea Matrix into Story Bible.
  - Guaranteed selected scenes retain complete dramatic wants, subtext, key dialogue beats, and agent sources.
  - Added direct action cards ("Draft CPSD (Phase 4)", "+ Add to Bible") and quick-add batch buttons for agent ideas.

- [x] **Step 4: Story Bible Schema Refinement**
  - Cleaned up `/src/types/storyBible.ts` for consistent typing across Scenes, Matrix Entries, Character Profiles, Worldbuilding, and CPSD Blueprints.

- [x] **Step 5: Backend API Endpoint Optimization (`/api/pipeline/*`)**
  - Verified server endpoints (`/server/geminiService.ts` & `/server/storyBibleManager.ts`) handle CPSD, screenplay generation, and multi-scene sync cleanly with `@google/genai`.

- [x] **Step 6: Model Selection Protocol & Clean Configuration**
  - Updated model list to official supported Gemini endpoints: `gemini-3.1-flash-lite`, `gemini-3.6-flash`, `gemini-2.5-flash`, `gemini-2.5-pro`, `gemini-3.1-pro-preview`, `gemini-flash-latest`, `gemma-4-26b-a4b-it`, `gemma-4-31b-it`.
  - Cleared invalid 404 model IDs (`gemini-3.1-flash-lite-latest`, `gemini-3.5-flash`) across constants, server services, and settings defaults.

- [x] **Step 7: Cinematic Skill Integration & Scene Focus Directives**
  - Injected `oscar-cinematic-storyteller.md` and `cinematic-scripting.md` into Phase 3 Scene Matrix generation and Phase 4 CPSD Document creation.
  - Added optional **AI Focus & Craft Directives** input fields in Phase 3 (Scene Matrix) and Phase 4 (CPSD Blueprint).
  - Enforced plot building, atmospheric setup, unsaid dialogue subtext, and sensory bridges in Scene 1 and subsequent scenes.

- [x] **Step 8: Verification & Final Build**
  - Executed `lint_applet` and `compile_applet` with zero TypeScript or build errors.
