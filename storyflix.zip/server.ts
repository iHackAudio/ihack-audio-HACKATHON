import express from "express";
import http from "http";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { WebSocketServer } from "ws";
import multer from "multer";
import { JARVIS_SYSTEM_INSTRUCTION } from "./server/instruction.ts";

const WORKSPACE_DIR = path.join(process.cwd(), "workspace files");
if (!fs.existsSync(WORKSPACE_DIR)) {
  fs.mkdirSync(WORKSPACE_DIR, { recursive: true });
}

function getWorkspaceRoot(): string {
  const defaultWorkspace = path.join(process.cwd(), "workspace files");
  if (!fs.existsSync(defaultWorkspace)) {
    fs.mkdirSync(defaultWorkspace, { recursive: true });
  }
  return defaultWorkspace;
}

function getSafePath(relativePath: string): string {
  const root = getWorkspaceRoot();
  const fullPath = path.resolve(root, relativePath);
  if (!fullPath.startsWith(root) && fullPath !== root) {
    throw new Error("Access denied: Path outside permitted directory root.");
  }
  return fullPath;
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, getWorkspaceRoot());
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});
const upload = multer({ storage });


async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));

  // 3.1 Set up /api/health
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Diagnostic endpoint to test all API keys and AI providers
  app.get("/api/test-keys", async (req, res) => {
    try {
      const { testAllKeys } = await import("./server/aiProviderService.ts");
      const results = await testAllKeys();
      res.json({ status: "completed", timestamp: new Date().toISOString(), results });
    } catch (e: any) {
      res.status(500).json({ error: e.message || String(e) });
    }
  });

  // Story Bible Management Endpoints
  app.get("/api/story-bible", async (req, res) => {
    try {
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const bible = loadStoryBible();
      res.json(bible);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/story-bible", async (req, res) => {
    try {
      const { saveStoryBible } = await import("./server/storyBibleManager.ts");
      const updated = saveStoryBible(req.body);
      res.json({ status: "success", bible: updated });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/story-bible/reset", async (req, res) => {
    try {
      const { saveStoryBible } = await import("./server/storyBibleManager.ts");
      const { createDefaultStoryBible } = await import("./src/types/storyBible.ts");
      const { saveQuestionnaire, getDefaultQuestionnaire } = await import("./server/questionnaireManager.ts");
      
      // Reset Story Bible to default state
      const defaultBible = createDefaultStoryBible();
      const savedBible = saveStoryBible(defaultBible);

      // Reset Questionnaire to default state
      const defaultQuestionnaire = getDefaultQuestionnaire();
      saveQuestionnaire(defaultQuestionnaire);

      // Clear all sub-agent memories for this session or globally
      const { clearSubAgent } = await import("./server/agentHub.ts");
      const sessionId = req.body?.sessionId || null;
      clearSubAgent(sessionId);

      res.json({ status: "success", bible: savedBible });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/story-bible/markdown", async (req, res) => {
    try {
      const { getStoryBibleMarkdown } = await import("./server/storyBibleManager.ts");
      const md = getStoryBibleMarkdown();
      res.json({ markdown: md });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/story-bible/import", async (req, res) => {
    try {
      const { importStoryBibleData } = await import("./server/storyBibleManager.ts");
      const payload = req.body.data || req.body;
      const imported = importStoryBibleData(payload);
      res.json({ status: "success", bible: imported });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/story-bible/export/json", async (req, res) => {
    try {
      const { getStoryBibleJsonPath, loadStoryBible } = await import("./server/storyBibleManager.ts");
      const title = req.query.title as string | undefined;
      const jsonPath = getStoryBibleJsonPath(title);
      if (!fs.existsSync(jsonPath)) {
        loadStoryBible(title);
      }
      res.download(jsonPath, path.basename(jsonPath));
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/story-bible/export/markdown", async (req, res) => {
    try {
      const { getStoryBibleMarkdownPath, loadStoryBible } = await import("./server/storyBibleManager.ts");
      const title = req.query.title as string | undefined;
      const mdPath = getStoryBibleMarkdownPath(title);
      if (!fs.existsSync(mdPath)) {
        loadStoryBible(title);
      }
      res.download(mdPath, path.basename(mdPath));
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Questionnaire & Information Gathering Endpoints
  app.get("/api/questionnaire", async (req, res) => {
    try {
      const { loadQuestionnaire } = await import("./server/questionnaireManager.ts");
      const q = loadQuestionnaire();
      res.json(q);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/questionnaire", async (req, res) => {
    try {
      const { saveQuestionnaire } = await import("./server/questionnaireManager.ts");
      const updated = saveQuestionnaire(req.body);
      res.json({ status: "success", questionnaire: updated });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/questionnaire/compile", async (req, res) => {
    try {
      const { loadQuestionnaire } = await import("./server/questionnaireManager.ts");
      const { loadStoryBible, saveStoryBible } = await import("./server/storyBibleManager.ts");
      const { compileQuestionnaireToBible } = await import("./server/geminiService.ts");

      const q = req.body.answers ? req.body : loadQuestionnaire();
      const currentBible = loadStoryBible();
      const newBible = await compileQuestionnaireToBible(q.answers || q, currentBible);
      const saved = saveStoryBible(newBible);
      res.json({ status: "success", bible: saved });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Validation & Critique Endpoints
  app.post("/api/validation/phase1-step", async (req, res) => {
    try {
      const { step, answers } = req.body;
      const { validatePhase1Step } = await import("./server/geminiService.ts");
      const result = await validatePhase1Step(step || 1, answers || {});
      res.json(result);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/validation/story-bible", async (req, res) => {
    try {
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const { validateStoryBible } = await import("./server/geminiService.ts");
      const { customInstruction } = req.body || {};
      const bible = loadStoryBible();
      const result = await validateStoryBible(bible, customInstruction);
      res.json(result);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/validation/scene-brief", async (req, res) => {
    try {
      const { sceneTitle, location, characters, brief, characterDetails, acousticDetails } = req.body;
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const { validateSceneBrief } = await import("./server/geminiService.ts");
      const bible = loadStoryBible();
      const result = await validateSceneBrief({
        sceneTitle: sceneTitle || bible.scenes?.[0]?.title || bible.concept.title || "Scene 1",
        location: location || bible.locations?.[0]?.name || "Main Location",
        characters: (Array.isArray(characters) && characters.length > 0 && characters[0]) ? characters : (bible.characterProfiles?.map(c => c.name) || [bible.concept.title || "Narrator"]),
        brief: brief || bible.scenes?.[0]?.summary || bible.concept.summary || bible.concept.hook || "Scene Brief",
        characterDetails,
        acousticDetails
      }, bible);
      res.json(result);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Scene Tournament Endpoints
  app.post("/api/tournament/generate", async (req, res) => {
    try {
      const { sceneTitle, location, characters, brief, cpsdDocument } = req.body;
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const { runSceneTournament } = await import("./server/geminiService.ts");
      const bible = loadStoryBible();

      const finalSceneTitle = sceneTitle || bible.scenes?.[0]?.title || bible.concept.title || "Scene 1";
      const finalLocation = location || bible.locations?.[0]?.name || "Main Location";
      const finalCharacters = (Array.isArray(characters) && characters.length > 0 && characters[0]) ? characters : (bible.characterProfiles?.map(c => c.name) || [bible.concept.title || "Narrator"]);
      const finalBrief = brief || bible.scenes?.[0]?.summary || bible.concept.summary || bible.concept.hook || "Scene Brief";

      const result = await runSceneTournament(
        finalSceneTitle,
        finalLocation,
        finalCharacters,
        finalBrief,
        bible,
        cpsdDocument
      );
      res.json(result);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Script Optimization Endpoints
  app.post("/api/script/optimize", async (req, res) => {
    try {
      const { approvedProse } = req.body;
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const { runStoryPolish } = await import("./server/geminiService.ts");
      const bible = loadStoryBible();

      const result = await runStoryPolish(approvedProse || "", bible);
      res.json(result);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/script/rewrite-line", async (req, res) => {
    try {
      const { fullScript, targetLineId, targetLineText, commentInstruction } = req.body;
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const { rewriteScriptLine } = await import("./server/geminiService.ts");
      const bible = loadStoryBible();

      const updatedScript = await rewriteScriptLine(
        fullScript || "",
        targetLineId || "L1",
        targetLineText || "",
        commentInstruction || "Tweak vocal tone",
        bible
      );
      res.json({ updatedScript });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/script/chat-edit", async (req, res) => {
    try {
      const { currentScript, userPrompt } = req.body;
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const { chatEditScript } = await import("./server/geminiService.ts");
      const bible = loadStoryBible();

      const result = await chatEditScript(currentScript || "", userPrompt || "", bible);
      res.json(result);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Express Simplified Pipeline Endpoints (Demo Mode & Direct Bible Attachment)
  app.post("/api/simplified-pipeline/express-generate", async (req, res) => {
    try {
      const { prompt, genre, tone, characterCount } = req.body;
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const { runSimplifiedExpressPipeline } = await import("./server/geminiService.ts");
      const currentBible = loadStoryBible();

      const result = await runSimplifiedExpressPipeline(
        prompt || "",
        genre,
        tone,
        characterCount ? Number(characterCount) : 2,
        currentBible
      );
      res.json(result);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/simplified-pipeline/apply-to-bible", async (req, res) => {
    try {
      const { payload } = req.body;
      const { loadStoryBible, saveStoryBible } = await import("./server/storyBibleManager.ts");
      const bible = loadStoryBible();

      if (payload) {
        if (payload.concept) {
          bible.concept = {
            ...bible.concept,
            title: payload.concept.title || bible.concept.title,
            hook: payload.concept.hook || bible.concept.hook,
            summary: payload.concept.summary || bible.concept.summary,
            genre: payload.concept.genre || bible.concept.genre,
            tone: payload.concept.tone || bible.concept.tone,
            targetEmotion: payload.concept.targetEmotion || bible.concept.targetEmotion
          };
        }

        if (Array.isArray(payload.characters) && payload.characters.length > 0) {
          bible.characterProfiles = payload.characters.map((c: any, idx: number) => ({
            id: `char_${idx + 1}`,
            name: c.name || `Character ${idx + 1}`,
            age: c.age || "30s",
            role: c.role || (idx === 0 ? "protagonist" : "supporting"),
            vocalProfile: c.vocalProfile || "Standard",
            voiceId: c.voiceId || "Kore",
            background: c.motivations || "",
            speechQuirks: c.speechQuirks || "",
            motivations: c.motivations || ""
          }));
        }

        if (payload.location) {
          bible.locations = [{
            id: "loc_1",
            name: payload.location.name || "Primary Location",
            description: payload.location.description || "",
            lighting: "Cinematic Ambient",
            acoustics: payload.location.acoustics || "Standard Echo",
            emotionalTension: "High"
          }];
        }

        if (Array.isArray(payload.scenes) && payload.scenes.length > 0) {
          bible.scenes = payload.scenes.map((s: any, idx: number) => ({
            id: `scene_${s.sceneNumber || idx + 1}`,
            sceneNumber: s.sceneNumber || idx + 1,
            title: s.title || `Scene ${idx + 1}`,
            location: s.location || payload.location?.name || "Main Location",
            charactersInScene: s.charactersInScene || [],
            summary: s.summary || "",
            status: idx === 0 ? "approved" : "draft",
            rawProse: idx === 0 ? (payload.generatedSceneProse || "") : "",
            scriptContent: idx === 0 ? (payload.generatedScreenplay || "") : "",
            jarvisScore: payload.jarvisScore || 9.2,
            jarvisFeedback: payload.jarvisDiagnostics?.editorNotes || "Express Pipeline compiled successfully.",
            updatedAt: Date.now(),
            emotionalBeat: s.emotionalBeat || ""
          }));
        }

        bible.updatedAt = Date.now();
        const saved = saveStoryBible(bible);
        return res.json({ status: "success", bible: saved, message: "Simplified pipeline story successfully attached to Story Bible!" });
      }

      res.status(400).json({ error: "Missing payload" });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Discussion Mode & Subtextual Reasoning Endpoints
  app.post("/api/discussion/chat", async (req, res) => {
    try {
      const { runSubtextDiscussion } = await import("./server/discussionService.ts");
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const currentBible = loadStoryBible();

      const payload = {
        userMessage: req.body.userMessage || "",
        currentPhase: req.body.currentPhase || 1,
        discussionHistory: req.body.discussionHistory || [],
        storyBible: req.body.storyBible || currentBible,
        locksMap: req.body.locksMap || {}
      };

      const result = await runSubtextDiscussion(payload);
      res.json(result);
    } catch (e: any) {
      console.error("[DiscussionEndpoint] Error:", e);
      res.status(500).json({ error: e.message || "Failed to generate discussion response" });
    }
  });

  // Local File Management Endpoints
  app.get("/api/files", (req, res) => {
    try {
      const targetSubDir = (req.query.path as string) || "";
      const fullPath = getSafePath(targetSubDir);
      
      if (!fs.existsSync(fullPath)) {
        return res.json({ files: [] });
      }

      const files = fs.readdirSync(fullPath, { withFileTypes: true })
        .filter(entry => {
          return !["node_modules", "dist", ".git", "package-lock.json", "server/agent_config.json", "server/agent_memory.json"].includes(entry.name);
        })
        .map(entry => {
          const entryRelativePath = path.join(targetSubDir, entry.name);
          const stats = fs.statSync(path.join(fullPath, entry.name));
          return {
            name: entry.name,
            path: entryRelativePath,
            isDirectory: entry.isDirectory(),
            size: stats.isDirectory() ? 0 : stats.size,
            updatedAt: stats.mtime
          };
        });

      res.json({ files });
    } catch(e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/files/upload", upload.single("file"), (req, res) => {
    try {
      if (!req.file) return res.status(400).json({ error: "No file uploaded" });
      const targetSubDir = (req.query.path as string) || "";
      if (targetSubDir) {
        const finalDir = getSafePath(targetSubDir);
        fs.mkdirSync(finalDir, { recursive: true });
        const srcPath = req.file.path;
        const finalDest = path.join(finalDir, req.file.originalname);
        if (srcPath !== finalDest) {
          fs.renameSync(srcPath, finalDest);
        }
      }
      res.json({ status: "success", file: req.file?.originalname });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/system-files/content/:filename", (req, res) => {
    try {
      const allowedFiles = [
        "JARVIS.md",
        "SESSION.md",
        "SYSTEM.md",
        "SYSTEM_ARCHITECTURE.md",
        "WORKFLOW_CHECKLIST.md",
        "plan.md"
      ];
      const filename = decodeURIComponent(req.params.filename);
      if (!allowedFiles.includes(filename)) {
        return res.status(403).json({ error: "Access denied: Not a permitted system file" });
      }
      const fullPath = path.join(process.cwd(), filename);
      if (!fs.existsSync(fullPath)) return res.status(404).json({ error: "Not found" });
      const content = fs.readFileSync(fullPath, "utf-8");
      res.json({ content });
    } catch(e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/files/content/:filename", (req, res) => {
    try {
      const filename = decodeURIComponent(req.params.filename);
      const fullPath = getSafePath(filename);
      if (!fs.existsSync(fullPath)) return res.status(404).json({ error: "Not found" });
      const content = fs.readFileSync(fullPath, "utf-8");
      res.json({ content });
    } catch(e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/files/content", (req, res) => {
    try {
      const { filename, content } = req.body;
      if (!filename) return res.status(400).json({ error: "Filename missing" });
      const fullPath = getSafePath(filename);
      fs.mkdirSync(path.dirname(fullPath), { recursive: true });
      fs.writeFileSync(fullPath, content || "", "utf-8");
      res.json({ status: "success" });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/files/folder", (req, res) => {
    try {
      const { path: dirPath } = req.body;
      if (!dirPath) return res.status(400).json({ error: "Path missing" });
      const fullPath = getSafePath(dirPath);
      fs.mkdirSync(fullPath, { recursive: true });
      res.json({ status: "success" });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.delete("/api/files/:filename", (req, res) => {
    try {
      const filename = decodeURIComponent(req.params.filename);
      const fullPath = getSafePath(filename);
      if (fs.existsSync(fullPath)) {
        const stats = fs.statSync(fullPath);
        if (stats.isDirectory()) {
          fs.rmSync(fullPath, { recursive: true, force: true });
        } else {
          fs.unlinkSync(fullPath);
        }
      }
      res.json({ status: "success" });
    } catch(e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Audio serving endpoint for synthesized MP3 files
  app.get("/api/audio/:filename", (req, res) => {
    try {
      const filename = path.basename(req.params.filename);
      const audioPath = path.join(process.cwd(), "output", filename);
      if (!fs.existsSync(audioPath)) {
        return res.status(404).json({ error: "Audio file not found" });
      }
      res.setHeader("Content-Type", "audio/mpeg");
      fs.createReadStream(audioPath).pipe(res);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Direct Edge-TTS synthesis REST API
  app.post("/api/tts/synthesize", async (req, res) => {
    try {
      const { script, voice, outputFileName } = req.body;
      if (!script) {
        return res.status(400).json({ error: "Script parameter is required." });
      }
      const { executeEdgeTts } = await import("./server/ttsService.ts");
      const result = await executeEdgeTts({ script, voice, outputFileName });
      if (result.status === "success") {
        res.json(result);
      } else {
        res.status(500).json(result);
      }
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/clear-history", async (req, res) => {
    try {
      const sessionId = req.body?.sessionId || null;
      const { clearSubAgent } = await import("./server/agentHub.ts");
      clearSubAgent(sessionId);
      res.json({ status: "success", message: "In-memory sub-agent history cleared successfully." });
    } catch (err: any) {
      console.error("Failed to clear sub-agent memory:", err);
      res.status(500).json({ error: err?.message || "Failed to clear memory" });
    }
  });

  app.post("/api/pipeline/reset-context", async (req, res) => {
    try {
      const { purgeSystemContext } = await import("./server/agentHub.ts");
      const { resetBible } = req.body || {};
      const result = purgeSystemContext(!!resetBible);
      res.json(result);
    } catch (err: any) {
      console.error("Failed to reset pipeline context:", err);
      res.status(500).json({ error: err?.message || "Failed to reset context" });
    }
  });

  app.get("/api/agent-config", async (req, res) => {
    try {
      const { loadAgentConfigs } = await import("./server/agentConfigManager.ts");
      const config = loadAgentConfigs();
      res.json(config);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/agent-config", async (req, res) => {
    try {
      const { saveAgentConfigs } = await import("./server/agentConfigManager.ts");
      saveAgentConfigs(req.body);
      res.json({ status: "success", config: req.body });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const { message, history, autoSpeechEnabled = true, sessionId = null, activePhase, activeTab } = req.body;
      const targetAgentId = req.body.agentId || "jarvis";
      
      const { chatWithSubAgent } = await import("./server/agentHub.ts");
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const { GoogleGenAI, Type } = await import("@google/genai");
      const key = process.env.GEMINI_API_KEY;
      if (!key) {
        return res.status(400).json({ error: "No API key" });
      }

      const activeBible = loadStoryBible();

      if (targetAgentId === "agentA" || targetAgentId === "agentB") {
        const reply = await chatWithSubAgent(targetAgentId, message, key, sessionId);
        return res.json({ text: reply, agentId: targetAgentId });
      } else {
        const ai = new GoogleGenAI({ apiKey: key });
        
        const phaseContext = activePhase 
          ? `[ACTIVE USER PIPELINE PHASE: Phase ${activePhase}]` 
          : (activeTab ? `[ACTIVE USER TAB: ${activeTab}]` : '[ACTIVE USER TAB: Production Pipeline]');

        const previousScenesList = (activeBible.scenes || [])
          .map((s) => `Scene ${s.sceneNumber}: ${s.title}
Location: ${s.location || "UnknownSetting"}
Summary: ${s.summary || "No summary"}
Characters in Scene: ${(s.charactersInScene || []).join(", ") || "None"}
Narrative Prose Sample: ${s.rawProse ? s.rawProse.substring(0, 1000) + "..." : "None"}
CPSD Blueprint: ${s.cpsdDocument ? s.cpsdDocument.substring(0, 1000) + "..." : "None"}
Script Segment: ${s.scriptContent ? s.scriptContent.substring(0, 1200) + "..." : "None"}`)
          .join("\n\n");

        const charactersList = (activeBible.characterProfiles || [])
          .map((c) => `Character Name: ${c.name}
Role: ${c.role} | Age: ${c.age} | Voice ID: ${c.voiceId} | Vocal Profile: ${c.vocalProfile}
Background: ${c.background || "None"}
Speech Quirks: ${c.speechQuirks || "None"}
Motivations: ${c.motivations || "None"}`)
          .join("\n\n");

        const matrixEntriesList = (activeBible.sceneIdeaMatrix || [])
          .map((m) => `Scene Matrix Selection for Scene ${m.sceneNumber}: ${m.selectedIdea?.title || m.title}
Summary: ${m.selectedIdea?.summary || m.summary}
Twist Hook: ${m.selectedIdea?.twistOrHook || "None"}
Dramatic Want: ${m.selectedIdea?.dramaticWant || "None"}
Subtext & Tension: ${m.selectedIdea?.subtextAndTension || "None"}
Dialogue Beats: ${(m.selectedIdea?.keyDialogueBeats || []).join("; ") || "None"}`)
          .join("\n\n");

        const bibleContext = `[CURRENT STORY BIBLE CONTEXT (ALL 5 PHASES VISIBLE TO J.A.R.V.I.S.)]:
- Title / Concept: ${activeBible.concept?.title || "Untitled Project"} (${activeBible.concept?.logline || "No logline defined"})
- Format & Genre: ${activeBible.concept?.format || "Audio Drama"} | ${activeBible.concept?.genreVibe || "Sci-Fi"}

[PHASE 1 INTAKE DETAILS]:
Theme: ${activeBible.phase1Intake?.theme || "None"}
Characters Overview: ${activeBible.phase1Intake?.charactersOverview || "None"}
Storyline Overview: ${activeBible.phase1Intake?.storylineOverview || "None"}
Genre Vibe: ${activeBible.phase1Intake?.genreVibe || "None"}
Format: ${activeBible.phase1Intake?.format || "None"}
User Revision Notes: ${activeBible.phase1Intake?.userRevisionNotes || "None"}

[PHASE 2 DETAILED PERSONAS]:
${charactersList || "No detailed character profiles defined yet."}

[PHASE 3 SCENE IDEA MATRIX GENERATIONS]:
${matrixEntriesList || "No scene idea matrix selection recorded yet."}

[PHASE 4 & 5 COMPLETED CINEMATIC SCENES & SCREENPLAYS]:
${previousScenesList || "No master scenes or screenplays completed yet."}`;

        const requestInstruction = `${req.body.instruction || JARVIS_SYSTEM_INSTRUCTION}\n\n${phaseContext}\n${bibleContext}\n\nNote: You are directly assisting the user on their active phase/tab. Provide concrete, actionable, and formatted answers according to their story bible data.`;
        const rawMiddlemanModel = req.body.middlemanModel || "gemini-2.5-flash";
        const middlemanModel = rawMiddlemanModel;
        
        // Re-hydrate full conversation context for J.A.R.V.I.S. from history
        const contents: any[] = [];
        if (Array.isArray(history) && history.length > 0) {
          let lastRole: string | null = null;
          for (const item of history) {
            const role = item.role === 'user' ? 'user' : 'model';
            // Gemini API requires strictly alternating role sequence (user -> model -> user -> model)
            if (role !== lastRole) {
              contents.push({
                role: role,
                parts: [{ text: item.content }]
              });
              lastRole = role;
            } else {
              // Merge successive turns of identical roles side-by-side to maintain valid structure
              if (contents.length > 0) {
                contents[contents.length - 1].parts[0].text += "\n\n" + item.content;
              } else {
                contents.push({
                  role: role,
                  parts: [{ text: item.content }]
                });
                lastRole = role;
              }
            }
          }
        }

        // Add user prompt to the alternating chain safely
        if (contents.length > 0 && contents[contents.length - 1].role === 'user') {
          contents[contents.length - 1].parts[0].text += "\n\n" + message;
        } else {
          contents.push({ role: "user", parts: [{ text: message }] });
        }

        // Attach image parts if provided in req.body.attachments
        if (Array.isArray(req.body.attachments) && req.body.attachments.length > 0) {
          const userParts = contents[contents.length - 1].parts;
          for (const att of req.body.attachments) {
            if (att.data && att.mimeType) {
              const base64Data = att.data.replace(/^data:image\/\w+;base64,/, "");
              userParts.push({
                inlineData: {
                  mimeType: att.mimeType,
                  data: base64Data
                }
              });
            }
          }
        }
        let loopLimit = 5;
        let responseText = "";
        let finalAudioUrl: string | undefined = undefined;
        let runLogs: any[] = [];
        let allToolResults: any[] = [];

        const { speechSynthesizerTool, executeEdgeTts } = await import("./server/ttsService.ts");

        const targetJarvisModel = req.body.model || req.body.jarvisModel || req.body.middlemanModel || "gemini-3.1-flash-lite";
        const fallbackModelList = Array.from(new Set([targetJarvisModel, "gemini-3.1-flash-lite", "gemini-3.6-flash", "gemini-2.5-flash"]));

        while (loopLimit > 0) {
          loopLimit--;

          let response: any = null;
          let lastError: any = null;

          for (const currentModelName of fallbackModelList) {
            try {
              response = await ai.models.generateContent({
                model: currentModelName,
                contents: contents,
                config: {
                  systemInstruction: requestInstruction,
                  tools: [{
                    functionDeclarations: [{
                      name: "message_agent",
                      description: "Send a message to a sub-agent. They will respond to you, and you can relay their findings. Available agents: agentA, agentB.",
                      parameters: {
                        type: Type.OBJECT,
                        properties: {
                          agentId: { 
                              type: Type.STRING, 
                              description: "The agent id (must be exactly 'agentA' or 'agentB')" 
                          },
                          message: { 
                              type: Type.STRING, 
                              description: "Your message or request to the sub-agent" 
                          }
                        },
                        required: ["agentId", "message"]
                      }
                    },
                    {
                      name: "run_scene_tournament",
                      description: "Run the 3-Writer Tournament (Writer A vs Writer B -> Writer C Synthesis) for a scene.",
                      parameters: {
                        type: Type.OBJECT,
                        properties: {
                          sceneTitle: { type: Type.STRING, description: "Title of the scene" },
                          location: { type: Type.STRING, description: "Location name" },
                          characters: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Character names in this scene" },
                          brief: { type: Type.STRING, description: "Creative brief and emotional stakes for the scene" }
                        },
                        required: ["sceneTitle", "brief"]
                      }
                    },
                    {
                      name: "run_story_polish",
                      description: "Polish an approved scene prose into a production script (Tightener, Voice Coach, Final Ear, JARVIS Editor).",
                      parameters: {
                        type: Type.OBJECT,
                        properties: {
                          sceneTitle: { type: Type.STRING, description: "Scene title" },
                          approvedProse: { type: Type.STRING, description: "The approved master prose to polish" }
                        },
                        required: ["approvedProse"]
                      }
                    },
                    {
                      name: "edit_script_line",
                      description: "Targeted rewrite of one specific line in a script.",
                      parameters: {
                        type: Type.OBJECT,
                        properties: {
                          sceneTitle: { type: Type.STRING, description: "Scene title" },
                          lineId: { type: Type.STRING, description: "Identifier of the target line" },
                          lineText: { type: Type.STRING, description: "Original target line text" },
                          instruction: { type: Type.STRING, description: "Revision instruction" },
                          fullScript: { type: Type.STRING, description: "The complete current script" }
                        },
                        required: ["lineText", "instruction", "fullScript"]
                      }
                    },
                    {
                      name: "chat_edit_script",
                      description: "Edit or refine a script or prose using natural language instructions.",
                      parameters: {
                        type: Type.OBJECT,
                        properties: {
                          sceneTitle: { type: Type.STRING, description: "Scene title" },
                          currentScript: { type: Type.STRING, description: "Current script or prose text" },
                          userPrompt: { type: Type.STRING, description: "Natural language edit instructions" }
                        },
                        required: ["currentScript", "userPrompt"]
                      }
                    },
                    {
                      name: "get_story_bible",
                      description: "Fetch the current Story Bible state.",
                      parameters: {
                        type: Type.OBJECT,
                        properties: {}
                      }
                    },
                    {
                      name: "update_ui_inputs",
                      description: "Directly fill or update UI textboxes, forms, and directives across all phases (Phase 1 Intake fields, Phase 2 Characters, Phase 3 Focus, Phase 4 CPSD Focus, Phase 5 Speech settings) after discussions with the user.",
                      parameters: {
                        type: Type.OBJECT,
                        properties: {
                          phase1Intake: { 
                            type: Type.OBJECT, 
                            description: "Phase 1 intake values to fill into UI textboxes: { theme?, charactersOverview?, storylineOverview?, format?, genreVibe? }" 
                          },
                          sceneCustomFocus: { type: Type.STRING, description: "Phase 3 custom scene matrix focus and directives" },
                          phase4CustomFocus: { type: Type.STRING, description: "Phase 4 CPSD scene blueprint craft directives" },
                          scriptingDirectives: { type: Type.STRING, description: "Phase 5 screenplay & voice acting directives" },
                          speechSettings: {
                            type: Type.OBJECT,
                            description: "Speech & Audio settings: { defaultNarratorVoice?, speechRate?, pitch?, backgroundAtmosphere? }"
                          },
                          summary: { type: Type.STRING, description: "Brief summary of what textboxes were filled or updated" }
                        }
                      }
                    },
                    {
                      name: "update_story_bible_phase",
                      description: "Update or customize any pipeline phase input or Story Bible fields (e.g., Phase 1 Intake, Phase 2 Personas, Phase 3 Scene Matrix, Phase 4 CPSD, concept, characterProfiles) based on user chat instructions.",
                      parameters: {
                        type: Type.OBJECT,
                        properties: {
                          phase: { type: Type.STRING, description: "The target phase number or name (e.g. '1', '2', '3', '4', '5')" },
                          updates: { type: Type.OBJECT, description: "Object containing fields to update in the Story Bible (e.g. { phase1Intake: {...} }, { characterProfiles: [...] }, { concept: {...} })" },
                          summary: { type: Type.STRING, description: "Brief description of changes made" }
                        },
                        required: ["phase", "updates"]
                      }
                    },
                    speechSynthesizerTool]
                  }]
                }
              });
              if (response) {
                break;
              }
            } catch (mErr: any) {
              lastError = mErr;
              console.warn(`[JARVIS Model Failure] Model '${currentModelName}' failed:`, mErr?.message || mErr);
            }
          }

          if (!response) {
            const isQuota = lastError?.message?.includes("429") || lastError?.message?.includes("quota") || lastError?.status === 429;
            if (isQuota) {
              return res.json({
                text: "⚠️ **Gemini API Quota Exceeded (429 Error)**\n\nThe current Gemini API key has exceeded its rate limit quota.\n\n### 🔧 How to Fix:\n1. Click **System Settings** in the top navigation bar.\n2. Under **Model Selection**, switch to another model (e.g. `gemini-3.5-flash` or `gemini-3.1-flash-lite`).\n3. Or enter your personal **Gemini API Key** or **Groq Key** in Settings, then click **Save Configuration**.",
                agentId: "jarvis",
                logs: runLogs
              });
            }
            throw lastError || new Error("Failed to generate content across all fallback models.");
          }

          const modelTurn = response.candidates?.[0]?.content;
          const functionCalls = response.functionCalls;

          if (modelTurn) {
            contents.push(modelTurn);
          }

          let pipelineToolResults: any[] = [];

          if (functionCalls && functionCalls.length > 0) {
            const functionResponses: any[] = [];
            const { executeToolCalls } = await import("./server/agentHub.ts");

            for (const call of functionCalls) {
              if (call.name === "message_agent") {
                const { agentId, message: agentMsg } = call.args as any;
                console.log(`[Text API ToolCall] message_agent: ${agentId} - ${agentMsg}`);
                try {
                  const rawReply = await chatWithSubAgent(agentId, agentMsg, key, sessionId);
                  const { summarizeForJarvis } = await import("./server/agentHub.ts");
                  const summary = await summarizeForJarvis(rawReply, key, middlemanModel);
                  
                  // Track telemetry logs for display in frontend AgentLogsPanel
                  runLogs.push({
                     agentId: agentId,
                     text: rawReply,
                     timestamp: Date.now()
                  });
                  runLogs.push({
                     agentId: "Gemma-Middleman",
                     text: `[${middlemanModel} Synthesis]:\n${summary}`,
                     timestamp: Date.now()
                  });

                  functionResponses.push({
                    name: "message_agent",
                    response: { agent_reply: summary }
                  });
                } catch (err: any) {
                  console.error(`[Text API ToolCall Error] ${agentId}:`, err);
                  functionResponses.push({
                    name: "message_agent",
                    response: { error: `Failed to communicate with ${agentId}: ${err.message}` }
                  });
                }
              } else if (call.name === "synthesizeSpeech") {
                const args = call.args as { script: string; voice: string; outputFileName: string };
                console.log(`[Edge-TTS Intercept] Synthesizing audio via Microsoft Edge Neural Voice (${args.voice})`);
                const ttsResult = await executeEdgeTts(args);
                runLogs.push({
                  agentId: "Edge-TTS-Engine",
                  text: `🔊 **[MICROSOFT EDGE-TTS GENERATED]**\n- Voice: \`${args.voice}\`\n- File: \`${args.outputFileName}\`\n- Audio URL: ${ttsResult.audioUrl}`,
                  timestamp: Date.now()
                });
                functionResponses.push({
                  name: "synthesizeSpeech",
                  response: ttsResult
                });
              } else if (
                call.name === "run_scene_tournament" ||
                call.name === "run_story_polish" ||
                call.name === "edit_script_line" ||
                call.name === "chat_edit_script" ||
                call.name === "get_story_bible" ||
                call.name === "update_story_bible_phase" ||
                call.name === "update_ui_inputs" ||
                call.name === "update_phase_data"
              ) {
                console.log(`[JARVIS Pipeline Tool Call] ${call.name}:`, call.args);
                const executed = await executeToolCalls([{ name: call.name, args: call.args as any }]);
                const toolRes = executed[0];
                pipelineToolResults.push(toolRes);
                allToolResults.push(toolRes);

                runLogs.push({
                  agentId: "jarvis-pipeline",
                  text: `🛠️ **[PIPELINE TOOL EXECUTED: ${call.name}]**\nStatus: ${toolRes?.status}`,
                  timestamp: Date.now()
                });

                functionResponses.push({
                  name: call.name,
                  response: toolRes?.data || { error: toolRes?.error }
                });
              }
            }

            // Provide tool responses straight back to Jarvis for synthesis
            contents.push({
              role: "user",
              parts: functionResponses.map((resp, idx) => ({
                functionResponse: {
                  name: resp.name,
                  id: functionCalls[idx].id,
                  response: resp.response
                }
              }))
            });
          } else {
            responseText = response.text || "";

            if (responseText && !responseText.includes("SYSTEM INSTRUCTION:") && autoSpeechEnabled) {
              console.log(`[Auto-Speech Intercept] Synthesizing Jarvis's final response...`);
              try {
                const autoTtsResult = await executeEdgeTts({
                  script: responseText,
                  voice: "en-US-AvaNeural",
                  outputFileName: `auto_response_${Date.now()}.mp3`
                });
                
                if (autoTtsResult.status === "success" && autoTtsResult.audioUrl) {
                  finalAudioUrl = autoTtsResult.audioUrl;
                  runLogs.push({
                    agentId: "Edge-TTS-Engine",
                    text: `🔊 **[AUTO-SPEECH ENABLED]** Generated MP3 for final response.\n- Audio URL: ${autoTtsResult.audioUrl}`,
                    timestamp: Date.now()
                  });
                }
              } catch (e) {
                console.error("Auto-Speech failed:", e);
              }
            }

            break;
          }
        }

        return res.json({ 
          text: responseText || "Cognitive pipeline successfully completed with no final text.", 
          audioUrl: finalAudioUrl,
          agentId: "jarvis", 
          logs: runLogs,
          toolResults: allToolResults
        });
      }
    } catch (err: any) {
      console.error("/api/chat error:", err);
      res.status(500).json({ error: err.message || "Failed to process chat" });
    }
  });

  // --- NEW SIMPLIFIED PIPELINE ENDPOINTS ---

  // Get current Story Bible JSON
  app.get("/api/bible/get", async (req, res) => {
    try {
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const bible = loadStoryBible();
      res.json(bible);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Get current Story Bible Markdown
  app.get("/api/bible/markdown", async (req, res) => {
    try {
      const { getStoryBibleMarkdown } = await import("./server/storyBibleManager.ts");
      const md = getStoryBibleMarkdown();
      res.type("text/markdown").send(md);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Import Story Bible JSON or raw object
  app.post("/api/bible/import", async (req, res) => {
    try {
      const { importStoryBibleData } = await import("./server/storyBibleManager.ts");
      const { purgeSystemContext } = await import("./server/agentHub.ts");
      const { data } = req.body;
      const imported = importStoryBibleData(data);
      purgeSystemContext();
      res.json({ success: true, bible: imported });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to import Story Bible" });
    }
  });

  // Run AI Critique & Validation on Story Bible
  app.post("/api/bible/critique", async (req, res) => {
    try {
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const { GoogleGenAI } = await import("@google/genai");
      const key = process.env.GEMINI_API_KEY;
      if (!key) return res.status(400).json({ error: "Missing Gemini API Key" });

      const bible = loadStoryBible();
      const ai = new GoogleGenAI({ apiKey: key });

      const prompt = `Analyze this Production Story Bible across Phase 1 Intake, Phase 2 Personas, Phase 3 Scene Matrix, and Phase 4 CPSD Documents.
Provide a structured assessment covering:
1. Overall Cohesion & Narrative Tone Score (1-10)
2. Character Bible Alignment (Are character motivations driving scene conflict?)
3. Scene Matrix Structure (Are scene goals and twists distinct?)
4. 3 Actionable Recommendations to elevate the production quality.

STORY BIBLE SNAPSHOT:
${JSON.stringify(bible, null, 2)}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt
      });

      res.json({ critique: response.text || "Story Bible passed validation analysis." });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Update Story Bible with lock status or partial changes
  app.post("/api/bible/update-phase", async (req, res) => {
    try {
      const { loadStoryBible, saveStoryBible } = await import("./server/storyBibleManager.ts");
      const currentBible = loadStoryBible();
      const { phase, updates, actionName, actionDetails } = req.body;

      const newHistoryEntry = {
        id: "rev_" + Date.now(),
        timestamp: Date.now(),
        phase: phase || "Phase Update",
        action: actionName || "Modified Phase Data",
        details: actionDetails || "Updated Story Bible state."
      };

      const updatedBible = {
        ...currentBible,
        ...updates,
        revisionHistory: [newHistoryEntry, ...(currentBible.revisionHistory || [])]
      };

      const saved = saveStoryBible(updatedBible);
      res.json({ success: true, bible: saved });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Phase 1: Multi-Input Unified Analysis
  app.post("/api/pipeline/phase1-analyze", async (req, res) => {
    try {
      const { analyzePhase1Intake } = await import("./server/geminiService.ts");
      const { theme, charactersOverview, storylineOverview, format, genreVibe } = req.body;
      const result = await analyzePhase1Intake({ theme, charactersOverview, storylineOverview, format, genreVibe });
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Phase 2: Forge Biometric Audio/Video Scan (max 9MB)
  app.post("/api/persona/forge-scan", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No audio or video file uploaded." });
      }
      const fileBuffer = fs.readFileSync(req.file.path);
      const mimeType = req.file.mimetype || "audio/mp3";
      const modelId = (req.body.modelId as string) || "gemini-2.5-flash";

      const { executeBiometricAudioScan } = await import("./server/geminiService.ts");
      const result = await executeBiometricAudioScan(fileBuffer, mimeType, modelId);
      
      // Clean up uploaded temp file
      try { fs.unlinkSync(req.file.path); } catch (e) {}

      res.json(result);
    } catch (err: any) {
      console.error("[Forge Scan API Error]", err);
      res.status(500).json({ error: err.message });
    }
  });

  // Phase 2: Architect Lab Persona System Prompt Generation
  app.post("/api/persona/architect-generate", async (req, res) => {
    try {
      const { generateArchitectPromptService } = await import("./server/geminiService.ts");
      const result = await generateArchitectPromptService(req.body);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Phase 2: Extract Proper Character Profiles from Intake Overview
  app.post("/api/persona/extract-characters", async (req, res) => {
    try {
      const { extractCharactersFromOverviewService } = await import("./server/geminiService.ts");
      const result = await extractCharactersFromOverviewService(req.body);
      res.json({ characters: result });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Phase 3: 9-Idea Scene Matrix Generation
  app.post("/api/pipeline/scene-matrix", async (req, res) => {
    try {
      const { generateSceneIdeaMatrixService } = await import("./server/geminiService.ts");
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const bible = loadStoryBible();
      const { pathType, userPlan, conceptSummary, customFocus } = req.body;
      const result = await generateSceneIdeaMatrixService(pathType, userPlan, conceptSummary, bible, customFocus);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Phase 3: Interactive Custom Scene Chat & Dialogue Flow Builder
  app.post("/api/pipeline/custom-scene-chat", async (req, res) => {
    try {
      const { generateCustomSceneDiscussionService } = await import("./server/geminiService.ts");
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const bible = loadStoryBible();
      const { userMessage, chatHistory, currentCustomScene } = req.body;
      const result = await generateCustomSceneDiscussionService(userMessage, chatHistory, currentCustomScene, bible);
      res.json(result);
    } catch (err: any) {
      console.error("Custom scene chat generation failed:", err);
      res.status(500).json({ error: err.message });
    }
  });

  // Phase 4: CPSD Scene Document Generation
  app.post("/api/pipeline/phase4-generate-cpsd", async (req, res) => {
    try {
      const { generatePhase4CpsdDocumentService } = await import("./server/geminiService.ts");
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const bible = loadStoryBible();
      const approvedScene = req.body.approvedScene || {};
      const customFocus = req.body.customFocus || "";
      const result = await generatePhase4CpsdDocumentService(approvedScene, bible, customFocus);
      res.json(result);
    } catch (err: any) {
      console.error("Phase 4 CPSD generation failed:", err);
      res.status(500).json({ error: err.message });
    }
  });

  
  // Phase 5: Cinematic Script Generation
  app.post("/api/pipeline/phase5-generate-script", async (req, res) => {
    try {
      const { generatePhase5CinematicScriptService } = await import("./server/geminiService.ts");
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const bible = loadStoryBible();
      const cpsdDocument = req.body.cpsdDocument;
      if (!cpsdDocument) {
        return res.status(400).json({ error: "No CPSD Document provided" });
      }
      const result = await generatePhase5CinematicScriptService(cpsdDocument, bible);
      res.json(result);
    } catch (err: any) {
      console.error("Phase 5 Script generation failed:", err);
      res.status(500).json({ error: err.message });
    }
  });

  // Phase 5 Step 1: Agentic Creative Pipeline (Agent A -> Agent B -> Agent C Draft with Margin Notes)
  app.post("/api/pipeline/phase5-agentic-pipeline", async (req, res) => {
    try {
      const { runAgenticCreativePipelineService } = await import("./server/geminiService.ts");
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const bible = loadStoryBible();
      const cpsdDocument = req.body.cpsdDocument;
      if (!cpsdDocument) {
        return res.status(400).json({ error: "No CPSD Document provided" });
      }
      const result = await runAgenticCreativePipelineService(cpsdDocument, bible);
      res.json(result);
    } catch (err: any) {
      console.error("Phase 5 Creative Pipeline step failed:", err);
      res.status(500).json({ error: err.message });
    }
  });

  // Phase 5 Step 2: Jarvis Production Polish (Stripping margin notes, anti-slop pass, direct speech synthesis ready)
  app.post("/api/pipeline/phase5-jarvis-polish", async (req, res) => {
    try {
      const { runJarvisProductionPolishService } = await import("./server/geminiService.ts");
      const { loadStoryBible } = await import("./server/storyBibleManager.ts");
      const bible = loadStoryBible();
      const { agentCDraft, cpsdDocument } = req.body;
      if (!agentCDraft) {
        return res.status(400).json({ error: "No Agent C stitched draft provided for Jarvis" });
      }
      const result = await runJarvisProductionPolishService(agentCDraft, bible, cpsdDocument);
      res.json(result);
    } catch (err: any) {
      console.error("Phase 5 Jarvis Polish step failed:", err);
      res.status(500).json({ error: err.message });
    }
  });

  // 3.2 Set up HTTP Server and WebSocket
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: "/live" });

  const { handleJarvisWebSocket } = await import("./server/agents/jarvis.ts");

  wss.on("connection", (ws, req) => {
    // Only Jarvis remains as the Live WS handler
    handleJarvisWebSocket(ws, req);
  });

  // 3.3 Verify Vite middleware loads in dev mode
  if (process.env.NODE_ENV !== "production") {
    console.log("Loading Vite Middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // 3.4 Verify server starts on PORT 3000
  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server starting on port ${PORT}`);
  });
}

startServer().catch(err => {
  console.error("Failed to start server:", err);
});

