import * as fs from "fs";
import * as path from "path";
import { AGENT_A_SYSTEM_INSTRUCTION, AGENT_B_SYSTEM_INSTRUCTION, MIDDLEMAN_SYSTEM_INSTRUCTION } from "./instruction";

const CONFIG_FILE = path.join(process.cwd(), "server", "agent_config.json");

export interface AgentConfig {
  enabled: boolean;
  systemInstruction?: string;
  model: string;
  liveModel?: string;
}

export interface SystemConfig {
  jarvis?: AgentConfig;
  agentA: AgentConfig;
  agentB: AgentConfig;
  middleman: AgentConfig;
  writerA?: AgentConfig;
  writerB?: AgentConfig;
  writerC?: AgentConfig;
  allowAppMutation?: boolean;
  groqApiKey?: string;
}

const DEFAULT_CONFIG: SystemConfig = {
  jarvis: {
    enabled: true,
    model: "gemini-3.6-flash",
    liveModel: "gemini-3.1-flash-live-preview"
  },
  agentA: {
    enabled: true,
    systemInstruction: AGENT_A_SYSTEM_INSTRUCTION,
    model: "gemini-3.1-flash-lite"
  },
  agentB: {
    enabled: true,
    systemInstruction: AGENT_B_SYSTEM_INSTRUCTION,
    model: "gemini-3.1-flash-lite"
  },
  middleman: {
    enabled: true,
    systemInstruction: MIDDLEMAN_SYSTEM_INSTRUCTION,
    model: "gemma-4-31b-it"
  },
  writerA: {
    enabled: true,
    model: "gemini-3.1-flash-lite"
  },
  writerB: {
    enabled: true,
    model: "gemini-3.1-flash-lite"
  },
  writerC: {
    enabled: true,
    model: "gemini-3.1-flash-lite"
  },
  allowAppMutation: true,
  groqApiKey: "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"
};

export function loadAgentConfigs(): SystemConfig {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const data = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf-8"));
      return {
        jarvis: { ...DEFAULT_CONFIG.jarvis, ...data.jarvis },
        agentA: { ...DEFAULT_CONFIG.agentA, ...data.agentA },
        agentB: { ...DEFAULT_CONFIG.agentB, ...data.agentB },
        middleman: { ...DEFAULT_CONFIG.middleman, ...data.middleman },
        writerA: { ...DEFAULT_CONFIG.writerA, ...data.writerA },
        writerB: { ...DEFAULT_CONFIG.writerB, ...data.writerB },
        writerC: { ...DEFAULT_CONFIG.writerC, ...data.writerC },
        allowAppMutation: data.allowAppMutation !== undefined ? data.allowAppMutation : DEFAULT_CONFIG.allowAppMutation,
        groqApiKey: data.groqApiKey !== undefined ? data.groqApiKey : DEFAULT_CONFIG.groqApiKey
      };
    }
  } catch (err) {
    console.error("Failed to load agent configs:", err);
  }
  return DEFAULT_CONFIG;
}

export function saveAgentConfigs(config: SystemConfig) {
  try {
    const parentDir = path.dirname(CONFIG_FILE);
    if (!fs.existsSync(parentDir)) {
      fs.mkdirSync(parentDir, { recursive: true });
    }
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save agent configs:", err);
  }
}
