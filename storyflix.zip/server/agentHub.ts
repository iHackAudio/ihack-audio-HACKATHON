import { GoogleGenAI } from "@google/genai";

import { AGENT_A_SYSTEM_INSTRUCTION, AGENT_B_SYSTEM_INSTRUCTION, MIDDLEMAN_SYSTEM_INSTRUCTION } from "./instruction";
import { loadAgentConfigs, saveAgentConfigs } from "./agentConfigManager";
import { runSceneTournament, runStoryPolish, rewriteScriptLine, chatEditScript } from "./geminiService";
import { loadStoryBible, saveStoryBible } from "./storyBibleManager";

import * as fs from "fs";
import * as path from "path";

const MEMORY_FILE = path.join(process.cwd(), "server", "agent_memory.json");

function loadMemory(): Record<string, any> {
  try {
    if (fs.existsSync(MEMORY_FILE)) {
      const raw = fs.readFileSync(MEMORY_FILE, "utf-8");
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error("Failed to load agent memory:", err);
  }
  return { agentA: [], agentB: [], jarvis_sessions: {} };
}

function saveMemory(mem: Record<string, any>) {
  try {
    const parentDir = path.dirname(MEMORY_FILE);
    if (!fs.existsSync(parentDir)) {
      fs.mkdirSync(parentDir, { recursive: true });
    }
    fs.writeFileSync(MEMORY_FILE, JSON.stringify(mem, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save agent memory:", err);
  }
}

// Simple history per agent ID to maintain conversation context across reboots.
export const systemMemory = loadMemory();

export function clearSubAgent(sessionId?: string | null) {
  if (sessionId) {
    if (systemMemory.jarvis_sessions && systemMemory.jarvis_sessions[sessionId]) {
      systemMemory.jarvis_sessions[sessionId] = [];
    }
    systemMemory[`${sessionId}_agentA`] = [];
    systemMemory[`${sessionId}_agentB`] = [];
  } else {
    systemMemory.agentA = [];
    systemMemory.agentB = [];
  }
  saveMemory(systemMemory);
}

export function purgeSystemContext(resetBible: boolean = false) {
  console.log("[Context Purge Trigger] Purging all active agent memories, subagent histories, and session caches.");
  systemMemory.agentA = [];
  systemMemory.agentB = [];
  systemMemory.jarvis_sessions = {};
  // Clear any dynamic session keys
  for (const key of Object.keys(systemMemory)) {
    if (Array.isArray(systemMemory[key])) {
      systemMemory[key] = [];
    } else if (typeof systemMemory[key] === 'object' && systemMemory[key] !== null) {
      systemMemory[key] = {};
    }
  }
  saveMemory(systemMemory);
  invalidateBibleCache();

  if (resetBible) {
    const { resetStoryBible } = require("./storyBibleManager.ts");
    resetStoryBible();
  }

  return { status: "success", message: "System context, active agent memories, and bible cache purged successfully." };
}

export function saveSystemMemory() {
  saveMemory(systemMemory);
}

export async function summarizeForJarvis(rawText: string, apiKey: string, modelName: string = "gemini-2.5-flash"): Promise<string> {
  const configs = loadAgentConfigs();
  const middlemanConfig = configs.middleman;

  if (middlemanConfig && !middlemanConfig.enabled) {
    console.log("[Synthesis Middleman] Middleware is disabled. Forwarding raw telemetry.");
    return rawText;
  }

  const ai = new GoogleGenAI({ apiKey });
  const modelToUse = modelName === "gemma-4-31b-it" ? "gemma-4-31b-it" : (middlemanConfig?.model || "gemini-2.5-flash");
  const systemInstruction = middlemanConfig?.systemInstruction || MIDDLEMAN_SYSTEM_INSTRUCTION;

  try {
    const { listFiles, readFile, writeFile } = await import("./../filesystem.ts");
    const { Type } = await import("@google/genai");
    
    let loopLimit = 3;
    let reply = "No response";
    let history: any[] = [{ role: "user", parts: [{ text: `[System Instruction for Middleware]:\n${systemInstruction}\n\n[Raw Text to Summarize]:\n${rawText}` }] }];

    while (loopLimit > 0) {
      loopLimit--;
      const response = await ai.models.generateContent({
        model: modelToUse, 
        contents: history,
        config: {
          tools: [{
            functionDeclarations: [{
              name: "list_workspace_files",
              description: "List all files present in the local workspace directory.",
              parameters: { type: Type.OBJECT, properties: {} }
            }, {
              name: "read_workspace_file",
              description: "Read the content of a specific file in the workspace.",
              parameters: {
                type: Type.OBJECT,
                properties: {
                  filename: { type: Type.STRING, description: "The name of the file to read" }
                },
                required: ["filename"]
              }
            }, {
              name: "write_workspace_file",
              description: "Create or write content to a file in the workspace.",
              parameters: {
                type: Type.OBJECT,
                properties: {
                  filename: { type: Type.STRING, description: "The name of the file to write" },
                  content: { type: Type.STRING, description: "The content to write to the file" }
                },
                required: ["filename", "content"]
              }
            }]
          }]
        }
      });
      
      const modelTurn = response.candidates?.[0]?.content;
      const functionCalls = response.functionCalls;

      if (modelTurn) {
        history.push(modelTurn);
      }

      if (functionCalls && functionCalls.length > 0) {
        const functionResponses: any[] = [];
        for (const call of functionCalls) {
          if (call.name === "write_workspace_file") {
            const { filename, content } = call.args as any;
            console.log(`[Synthesis Middleman ToolCall] write_workspace_file: ${filename}`);
            try {
              await writeFile(filename, content);
              functionResponses.push({
                name: "write_workspace_file",
                response: { status: "success" }
              });
            } catch (err: any) {
              functionResponses.push({
                name: "write_workspace_file",
                response: { error: err.message }
              });
            }
          } else if (call.name === "list_workspace_files") {
            console.log(`[Synthesis Middleman ToolCall] list_workspace_files`);
            try {
              const files = await listFiles(".");
              functionResponses.push({
                name: "list_workspace_files",
                response: { files: files.map(f => f.name) }
              });
            } catch (err: any) {
              functionResponses.push({
                name: "list_workspace_files",
                response: { error: err.message }
              });
            }
          } else if (call.name === "read_workspace_file") {
            const { filename } = call.args as any;
            console.log(`[Synthesis Middleman ToolCall] read_workspace_file: ${filename}`);
            try {
              const fileContent = await readFile(filename);
              functionResponses.push({
                name: "read_workspace_file",
                response: { content: fileContent }
              });
            } catch (err: any) {
              functionResponses.push({
                name: "read_workspace_file",
                response: { error: err.message }
              });
            }
          }
        }

        history.push({
          role: "user",
          parts: functionResponses.map((resp, idx) => ({
            functionResponse: {
              name: resp.name,
              id: functionCalls[idx].id,
              response: resp.response
            }
          }))
        });
      } else {
        reply = response.text || rawText.substring(0, 500) + "... [Summary failed]";
        break;
      }
    }
    return reply;
  } catch (err: any) {
    console.error("Middleware summary failed with model:", modelToUse, err);
    return rawText.substring(0, 500) + "... [Summarization error]"; // fallback
  }
}

export async function chatWithSubAgent(targetAgentId: string, message: string, apiKey: string, sessionId?: string | null): Promise<string> {
  const configs = loadAgentConfigs();
  const agentKey = targetAgentId as "agentA" | "agentB" | "middleman";
  const agentConfig = configs[agentKey];

  if (!agentConfig) {
    throw new Error(`Agent ${targetAgentId} is not registered in the system.`);
  }

  if (!agentConfig.enabled) {
    throw new Error(`Agent [${targetAgentId}] is currently powered down (disabled). Please execute tool update_agent_configuration to enable them if you desire services.`);
  }

  const ai = new GoogleGenAI({ apiKey });
  const modelToUse = agentConfig.model || "gemini-3.1-flash-lite";

  const memoryKey = sessionId ? `${sessionId}_${targetAgentId}` : targetAgentId;

  // Initialize context if it was cleared
  if (!systemMemory[memoryKey]) {
    systemMemory[memoryKey] = [];
  }

  // Record incoming message from Jarvis
  systemMemory[memoryKey].push({ 
    role: "user", 
    parts: [{ text: `[Message from Jarvis]: ${message}` }] 
  });
  saveMemory(systemMemory);

  const { listFiles, readFile, writeFile } = await import("./../filesystem.ts");
  const { Type } = await import("@google/genai");

  let loopLimit = 3;
  let reply = "No response";

  while (loopLimit > 0) {
    loopLimit--;
    const response = await ai.models.generateContent({
      model: modelToUse, 
      contents: systemMemory[memoryKey],
      config: {
        systemInstruction: agentConfig.systemInstruction + "\n\nWORKSPACE ACCESS MODULE ON:\nYou have direct access to list, read, and write files in the local workspace via tools. When commanded to write or save files, execute them in parallel and confirm the status to Jarvis.",
        tools: [{
          functionDeclarations: [{
            name: "list_workspace_files",
            description: "List all files present in the local workspace directory.",
            parameters: { type: Type.OBJECT, properties: {} }
          }, {
            name: "read_workspace_file",
            description: "Read the content of a specific file in the workspace.",
            parameters: {
              type: Type.OBJECT,
              properties: {
                filename: { type: Type.STRING, description: "The name of the file to read" }
              },
              required: ["filename"]
            }
          }, {
            name: "write_workspace_file",
            description: "Create or write content to a file in the workspace.",
            parameters: {
              type: Type.OBJECT,
              properties: {
                filename: { type: Type.STRING, description: "The name of the file to write" },
                content: { type: Type.STRING, description: "The content to write to the file" }
              },
              required: ["filename", "content"]
            }
          }]
        }]
      }
    });

    const modelTurn = response.candidates?.[0]?.content;
    const functionCalls = response.functionCalls;

    if (modelTurn) {
      systemMemory[memoryKey].push(modelTurn);
    }

    if (functionCalls && functionCalls.length > 0) {
      const functionResponses: any[] = [];
      for (const call of functionCalls) {
        if (call.name === "write_workspace_file") {
          const { filename, content } = call.args as any;
          console.log(`[Sub-Agent ${targetAgentId} ToolCall] write_workspace_file: ${filename}`);
          try {
            await writeFile(filename, content);
            functionResponses.push({
              name: "write_workspace_file",
              response: { status: "success" }
            });
          } catch (err: any) {
            functionResponses.push({
              name: "write_workspace_file",
              response: { error: err.message }
            });
          }
        } else if (call.name === "list_workspace_files") {
          console.log(`[Sub-Agent ${targetAgentId} ToolCall] list_workspace_files`);
          try {
            const files = await listFiles(".");
            functionResponses.push({
              name: "list_workspace_files",
              response: { files: files.map(f => f.name) }
            });
          } catch (err: any) {
            functionResponses.push({
              name: "list_workspace_files",
              response: { error: err.message }
            });
          }
        } else if (call.name === "read_workspace_file") {
          const { filename } = call.args as any;
          console.log(`[Sub-Agent ${targetAgentId} ToolCall] read_workspace_file: ${filename}`);
          try {
            const fileContent = await readFile(filename);
            functionResponses.push({
              name: "read_workspace_file",
              response: { content: fileContent }
            });
          } catch (err: any) {
            functionResponses.push({
              name: "read_workspace_file",
              response: { error: err.message }
            });
          }
        }
      }

      systemMemory[memoryKey].push({
        role: "user",
        parts: functionResponses.map((resp, idx) => ({
          functionResponse: {
            name: resp.name,
            id: functionCalls[idx].id,
            response: resp.response
          }
        }))
      });
      saveMemory(systemMemory);
    } else {
      reply = response.text || "No response";
      break;
    }
  }

  saveMemory(systemMemory);
  return reply;
}

// ── BIBLE CACHING & TOOL EXECUTION FOR JARVIS ──
const bibleCache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL_MS = 30000;

export async function loadStoryBibleCached(): Promise<any> {
  const cacheKey = "story_bible";
  const cached = bibleCache.get(cacheKey);

  if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
    return cached.data;
  }

  const bible = await loadStoryBible();
  bibleCache.set(cacheKey, { data: bible, timestamp: Date.now() });
  return bible;
}

export function invalidateBibleCache() {
  bibleCache.delete("story_bible");
}

export interface ToolCallPayload {
  name: string;
  args: Record<string, any>;
}

export async function executeToolCalls(calls: ToolCallPayload[]): Promise<any[]> {
  const results: any[] = [];

  for (const call of calls) {
    console.log(`[JARVIS Pipeline Tool] Executing: ${call.name}`, call.args);
    try {
      const result = await executeSingleTool(call);
      results.push({
        tool: call.name,
        status: "success",
        data: result
      });
    } catch (err: any) {
      console.error(`[JARVIS Pipeline Tool Error] ${call.name} failed:`, err);
      results.push({
        tool: call.name,
        status: "error",
        error: err?.message || "Tool execution failed"
      });
    }
  }

  return results;
}

async function executeSingleTool(call: ToolCallPayload): Promise<any> {
  const args = call.args || {};

  switch (call.name) {
    case "run_scene_tournament": {
      const bible = await loadStoryBibleCached();
      const sceneTitle = args.sceneTitle || "Current Scene";
      const location = args.location || "Unspecified Location";
      const characters = Array.isArray(args.characters) ? args.characters : [];
      const brief = args.brief || "High tension scene";

      const result = await runSceneTournament(sceneTitle, location, characters, brief, bible);
      invalidateBibleCache();

      return {
        draftA: result.writerA,
        draftB: result.writerB,
        masterScene: result.writerC,
        emotionalBeat: result.emotionalBeat
      };
    }

    case "run_story_polish": {
      const bible = await loadStoryBibleCached();
      const approvedProse = args.approvedProse || "";
      const sceneTitle = args.sceneTitle || "Active Scene";

      const result = await runStoryPolish(approvedProse, bible, sceneTitle);
      invalidateBibleCache();

      return {
        slotA: result.slotA,
        slotB: result.slotB,
        slotC: result.slotC,
        jarvisScore: result.jarvisScore,
        jarvisReport: result.jarvisReport,
        finalScript: result.jarvisFinal
      };
    }

    case "edit_script_line": {
      const bible = await loadStoryBibleCached();
      const fullScript = args.fullScript || "";
      const lineId = args.lineId || "line-1";
      const lineText = args.lineText || "";
      const instruction = args.instruction || "";

      const updatedScript = await rewriteScriptLine(fullScript, lineId, lineText, instruction, bible);
      invalidateBibleCache();

      return {
        updatedScript,
        lineId,
        changeInstruction: instruction
      };
    }

    case "chat_edit_script": {
      const bible = await loadStoryBibleCached();
      const currentScript = args.currentScript || "";
      const userPrompt = args.userPrompt || "";

      const result = await chatEditScript(currentScript, userPrompt, bible);
      invalidateBibleCache();

      return {
        updatedScript: result.updatedScript,
        agentReply: result.agentReply
      };
    }

    case "get_story_bible": {
      return await loadStoryBibleCached();
    }

    case "update_ui_inputs": {
      const currentBible = await loadStoryBibleCached();
      const cleanUpdates: Record<string, any> = {};

      if (args.phase1Intake) {
        cleanUpdates.phase1Intake = {
          ...(currentBible.phase1Intake || {}),
          ...args.phase1Intake
        };
      }
      if (args.sceneCustomFocus) {
        cleanUpdates.customFocus = args.sceneCustomFocus;
      }
      if (args.phase4CustomFocus) {
        cleanUpdates.phase4CustomFocus = args.phase4CustomFocus;
      }
      if (args.scriptingDirectives) {
        cleanUpdates.scriptingDirectives = args.scriptingDirectives;
      }
      if (args.speechSettings) {
        cleanUpdates.audioProductionSettings = {
          ...(currentBible.audioProductionSettings || {}),
          ...args.speechSettings
        };
      }
      if (args.characterProfiles) {
        cleanUpdates.characterProfiles = args.characterProfiles;
      }

      const newHistoryEntry = {
        id: "rev_" + Date.now(),
        timestamp: Date.now(),
        phase: "System Manager UI Fill",
        action: "JARVIS Copilot Interactive Update",
        details: args.summary || "JARVIS Copilot automatically populated workspace UI inputs after discussion."
      };

      const updatedBible = {
        ...currentBible,
        ...cleanUpdates,
        revisionHistory: [newHistoryEntry, ...(currentBible.revisionHistory || [])]
      };

      saveStoryBible(updatedBible);
      invalidateBibleCache();

      return {
        status: "success",
        message: args.summary || "JARVIS Copilot successfully updated workspace UI textboxes and directives.",
        updatedBible
      };
    }

    case "update_story_bible_phase":
    case "update_phase_data": {
      const currentBible = await loadStoryBibleCached();
      const phase = args.phase || "User Phase Update";
      const updates = args.updates || args.data || args;

      // Deep clean updates object if it contains wrapper fields
      const cleanUpdates: Record<string, any> = {};
      if (typeof updates === 'object' && updates !== null) {
        for (const [key, value] of Object.entries(updates)) {
          if (key !== 'phase' && key !== 'name') {
            cleanUpdates[key] = value;
          }
        }
      }

      const newHistoryEntry = {
        id: "rev_" + Date.now(),
        timestamp: Date.now(),
        phase: `Phase ${phase}`,
        action: "AI Chat Tool Edit",
        details: args.summary || "Updated story bible fields via Jarvis chat tool call."
      };

      const updatedBible = {
        ...currentBible,
        ...cleanUpdates,
        revisionHistory: [newHistoryEntry, ...(currentBible.revisionHistory || [])]
      };

      saveStoryBible(updatedBible);
      invalidateBibleCache();

      return {
        status: "success",
        message: `Successfully updated Story Bible for Phase ${phase}.`,
        updatedBible
      };
    }

    default:
      throw new Error(`Unknown pipeline tool: ${call.name}`);
  }
}

