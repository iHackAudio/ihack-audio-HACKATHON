import { WebSocket } from "ws";
import { GoogleGenAI, Type } from "@google/genai";
import { chatWithSubAgent, summarizeForJarvis, systemMemory, saveSystemMemory } from "../agentHub";
import { JARVIS_SYSTEM_INSTRUCTION } from "../instruction";
import { loadAgentConfigs, saveAgentConfigs } from "../agentConfigManager";
import { listFiles, readFile, writeFile } from "../../filesystem";
import { speechSynthesizerTool, executeEdgeTts } from "../ttsService";

export async function handleJarvisWebSocket(clientWs: WebSocket, req: any) {
  const url = new URL(req.url || "", `http://${req.headers.host}`);
  let key = url.searchParams.get("key");
  if (!key || key === "SIMULATION_KEY") {
    key = process.env.GEMINI_API_KEY || key;
  }
  const model = url.searchParams.get("model") || "gemini-3.1-flash-live-preview";
  const voice = url.searchParams.get("voice") || "Despina";
  const rawInstruction = url.searchParams.get("instruction") || "";
  const sessionId = url.searchParams.get("session_id") || "default";

  if (!systemMemory.jarvis_sessions) {
    systemMemory.jarvis_sessions = {};
  }
  if (!systemMemory.jarvis_sessions[sessionId]) {
    systemMemory.jarvis_sessions[sessionId] = [];
  }

  const isDefaultInstruction = !rawInstruction || 
    rawInstruction === "You are Jarvis. Be concise and professional." || 
    rawInstruction.includes("You are Jarvis, an advanced Agentic AI Assistant and Task manager. You are the Lead agent and manage other agents") ||
    rawInstruction.includes("You are J.A.R.V.I.S. (Just A Rather Very Intelligent System)");
  const instruction = isDefaultInstruction ? JARVIS_SYSTEM_INSTRUCTION : rawInstruction;
  const rawMiddlemanModel = url.searchParams.get("middlemanModel") || "gemini-2.5-flash";
  const middlemanModel = rawMiddlemanModel;

  if (!key) {
    clientWs.send(JSON.stringify({ error: "No API key" }));
    clientWs.close();
    return;
  }

  const ai = new GoogleGenAI({ apiKey: key });
  let session: any = null;

  const safeSend = (payload: any) => {
    if (clientWs.readyState === WebSocket.OPEN) {
      try {
        clientWs.send(JSON.stringify(payload));
      } catch (e) {
        console.error("Failed to safely send to clientWs:", e);
      }
    }
  };

  let lastUserPrompt: string | null = null;
  let toolCallTriggeredForCurrentPrompt = false;
  let watchdogTimer: NodeJS.Timeout | null = null;

  const clearWatchdog = (reason: string) => {
    if (watchdogTimer) {
      console.log(`[Watchdog Clear] Timer cleared. Reason: ${reason}`);
      clearTimeout(watchdogTimer);
      watchdogTimer = null;
    }
  };

  const startWatchdog = (userPrompt: string) => {
    if (watchdogTimer) {
      clearTimeout(watchdogTimer);
    }
    const cleanPrompt = (userPrompt || "").trim();
    if (cleanPrompt.length < 12) {
      console.log(`[Watchdog] Skipping timer: prompt too short ("${cleanPrompt}")`);
      return;
    }
    lastUserPrompt = cleanPrompt;
    toolCallTriggeredForCurrentPrompt = false;

    console.log(`[Watchdog] 7s watchdog timer armed for prompt: "${cleanPrompt}"`);

    watchdogTimer = setTimeout(async () => {
      if (toolCallTriggeredForCurrentPrompt) {
        console.log(`[Watchdog Check] J.A.R.V.I.S. delivered the task properly within 7s. Watchdog stands down.`);
        return;
      }

      console.warn(`[Watchdog Intervention] J.A.R.V.I.S. did not trigger agent-communication within 7s! Intercepting pipeline.`);
      
      try {
        // Broadcast telemetry logs and show Gemma active
        safeSend({ agentStatus: { agentId: "jarvis", status: "thinking" } });
        safeSend({ 
          agentChat: { 
            agentId: "Gemma-Middleman", 
            text: `⚠️ **[WATCHDOG INTERVENTION ENFORCED]** J.A.R.V.I.S. tool latency exceeded 7s. The Gemma Core is bypass-routing the task autonomously to ensure integrity.` 
          } 
        });

        // 1. Analyze prompt to determine target sub-agents
        const routerAI = new GoogleGenAI({ apiKey: key as string });
        const routingResponse = await routerAI.models.generateContent({
          model: "gemini-2.5-flash",
          contents: [{ 
            role: "user", 
            parts: [{ 
              text: `Evaluate this user workspace query: "${cleanPrompt}"
Decide which sub-agents MUST be delegated to perform this request:
- 'agentA' (Analytical Core): Programmed for quantitative, math, structural, code, optimization, clinical data mapping.
- 'agentB' (Creative Core): Tuned for qualitative, narrative design, layout/UX concepts, or patient-aligned feedback.

Respond with exactly a JSON array containing the agent IDs (e.g. ["agentA"] or ["agentA", "agentB"]). Do not provide any markdown formatting or comments other than the valid JSON.` 
            }] 
          }]
        });

        let targetAgents: string[] = ["agentA"];
        try {
          const rawText = routingResponse.text?.trim() || "";
          const cleanedText = rawText.replace(/```json/g, "").replace(/```/g, "").trim();
          const parsed = JSON.parse(cleanedText);
          if (Array.isArray(parsed) && parsed.length > 0) {
            targetAgents = parsed;
          }
        } catch (je) {
          console.warn("[Watchdog] Router JSON parse failed, defaulting to agentA. Raw response:", routingResponse.text);
        }

        console.log(`[Watchdog Auto-Route] Running sub-agents direct trace:`, targetAgents);

        // 2. Query target sub-agents directly
        for (const agentId of targetAgents) {
          safeSend({ agentStatus: { agentId, status: "working" } });
          safeSend({ 
            agentChat: { 
              agentId, 
              text: `🔄 *[Gemma Watchdog Intercept]* Executing analysis on core: "${cleanPrompt}"` 
            } 
          });

          // Execute agent execution
          const rawReply = await chatWithSubAgent(agentId, cleanPrompt, key as string);
          
          // Render raw trace to logger panel
          safeSend({ 
            agentChat: { 
              agentId, 
              text: rawReply 
            } 
          });

          // Process through the designated Gemma synthesis middleman
          const summary = await summarizeForJarvis(rawReply, key as string, middlemanModel);
          safeSend({ 
            agentChat: { 
              agentId: "Gemma-Middleman", 
              text: `[${middlemanModel} Synthesis - Watchdog Override for ${agentId}]:\n${summary}` 
            } 
          });

          safeSend({ agentStatus: { agentId, status: "idle" } });

          // 3. Inject the compiled synthesis direct to J.A.R.V.I.S.'s context buffer
          if (session) {
            session.sendClientContent({
              turns: [{
                role: "user",
                parts: [{
                  text: `SYSTEM WATCHDOG OVERRIDE: J.A.R.V.I.S., tool delivery failed the 7-second timing limit. Auto-monitoring has resolved the task using the sub-agent "${agentId}".
Here is their compiled synthesis and telemetry:

${summary}

Integrate this completed result into your final report and vocalize it with your trademark poise and British wit.`
                }]
              }],
              turnComplete: true
            });
          }
        }
        
        safeSend({ agentStatus: { agentId: "jarvis", status: "idle" } });

      } catch (err: any) {
        console.error("[Watchdog Intervene Error]", err);
        safeSend({ 
          agentChat: { 
            agentId: "Gemma-Middleman", 
            text: `❌ *[Watchdog Intercept Failed]*: ${err.message}` 
          } 
        });
      }
    }, 7000); // Strict 7s timeout
  };

  try {
    session = await ai.live.connect({
      model: model,
      callbacks: {
        onopen: () => {
          safeSend({ status: "connected" });
          safeSend({ agentStatus: { agentId: "jarvis", status: "active" } });

          // Hydrate conversation memory if recovering
          if (sessionId && systemMemory.jarvis_sessions[sessionId].length > 0) {
            console.log(`[Jarvis Session] Hydrating ${systemMemory.jarvis_sessions[sessionId].length} turns for session ${sessionId}`);
            // Group turns strictly so we don't violate Gemini alternating rules
            const turns: any[] = [];
            let lastRole: string | null = null;
            for (const item of systemMemory.jarvis_sessions[sessionId]) {
              if (item.role !== lastRole) {
                turns.push({ role: item.role, parts: [{ text: item.content }] });
                lastRole = item.role;
              } else {
                turns[turns.length - 1].parts[0].text += "\n\n" + item.content;
              }
            }
            if (turns.length > 0) {
              try {
                session.sendClientContent({ turns, turnComplete: true });
              } catch (e) {
                console.warn("[Jarvis Session] Failed to hydrate past context:", e);
              }
            }
          }
        },
        onmessage: async (message: any) => {
          const content = message.serverContent;
          const toolCalls = message.toolCall;

          if (toolCalls) {
            const functionResponses = [];
            for (const toolCall of toolCalls.functionCalls) {
              if (toolCall.name === "message_agent") {
                const { agentId, message: agentMsg } = toolCall.args;
                console.log(`[Jarvis ToolCall] message_agent: ${agentId} - ${agentMsg}`);
                
                // Clear the watchdog as Jarvis called the sub-agent properly
                toolCallTriggeredForCurrentPrompt = true;
                clearWatchdog("tool call message_agent triggered");

                // Animate agent status in frontend
                safeSend({ agentStatus: { agentId, status: "working" } });

                try {
                  const rawReply = await chatWithSubAgent(agentId, agentMsg, key as string);
                  console.log(`[Jarvis ToolCall Raw Reply] ${agentId}: ${rawReply.substring(0, 100)}...`);
                  
                  // Path 1: Raw Output direct to Chat UI
                  safeSend({ agentChat: { agentId, text: rawReply } });

                  // Path 2: Smart Summary via Middleware
                  const summary = await summarizeForJarvis(rawReply, key as string, middlemanModel);
                  console.log(`[Jarvis ToolCall Summary from ${middlemanModel}] ${summary}`);

                  // Also broadcast the middleman output to the UI logs
                  safeSend({ agentChat: { agentId: 'Gemma-Middleman', text: `[${middlemanModel} Synthesis]:\n${summary}` } });

                  // Set back to idle
                  safeSend({ agentStatus: { agentId, status: "idle" } });

                  // Return ONLY the compressed summary to Jarvis's audio context buffer
                  functionResponses.push({
                    name: "message_agent",
                    id: toolCall.id,
                    response: { agent_reply: summary }
                  });
                } catch (err: any) {
                  safeSend({ agentStatus: { agentId, status: "idle" } });
                  functionResponses.push({
                    name: "message_agent",
                    id: toolCall.id,
                    response: { error: `Failed to communicate with ${agentId}: ${err.message}` }
                  });
                }
              } else if (toolCall.name === "message_multiple_agents") {
                const { messageForA, messageForB } = toolCall.args;
                console.log(`[Jarvis ToolCall] message_multiple_agents`);
                
                // Clear the watchdog as Jarvis called the sub-agent properly
                toolCallTriggeredForCurrentPrompt = true;
                clearWatchdog("tool call message_multiple_agents triggered");

                // Animate agent status in frontend
                safeSend({ agentStatus: { agentId: "agentA", status: "working" } });
                safeSend({ agentStatus: { agentId: "agentB", status: "working" } });

                try {
                  const [replyA, replyB] = await Promise.all([
                    chatWithSubAgent("agentA", messageForA, key as string),
                    chatWithSubAgent("agentB", messageForB, key as string)
                  ]);
                  
                  // Path 1: Raw Output direct to Chat UI
                  safeSend({ agentChat: { agentId: "agentA", text: replyA } });
                  safeSend({ agentChat: { agentId: "agentB", text: replyB } });

                  // Path 2: Smart Summary via Middleware
                  const combined = `[Agent A]: ${replyA}\n\n[Agent B]: ${replyB}`;
                  const summary = await summarizeForJarvis(combined, key as string, middlemanModel);

                  // Also broadcast the middleman output to the UI logs
                  safeSend({ agentChat: { agentId: 'Gemma-Middleman', text: `[${middlemanModel} Synthesis - Dual Stream]:\n${summary}` } });

                  // Set back to idle
                  safeSend({ agentStatus: { agentId: "agentA", status: "idle" } });
                  safeSend({ agentStatus: { agentId: "agentB", status: "idle" } });

                  // Return ONLY the compressed summary to Jarvis's audio context buffer
                  functionResponses.push({
                    name: "message_multiple_agents",
                    id: toolCall.id,
                    response: { combined_agent_reply: summary }
                  });
                } catch (err: any) {
                  safeSend({ agentStatus: { agentId: "agentA", status: "idle" } });
                  safeSend({ agentStatus: { agentId: "agentB", status: "idle" } });
                  functionResponses.push({
                    name: "message_multiple_agents",
                    id: toolCall.id,
                    response: { error: `Failed to communicate with agents: ${err.message}` }
                  });
                }
              } else if (toolCall.name === "get_agent_configuration") {
                console.log(`[Jarvis ToolCall] get_agent_configuration`);
                try {
                  const configs = loadAgentConfigs();
                  safeSend({ agentConfigUpdate: configs });
                  functionResponses.push({
                    name: "get_agent_configuration",
                    id: toolCall.id,
                    response: { status: "success", configs }
                  });
                } catch (err: any) {
                  functionResponses.push({
                    name: "get_agent_configuration",
                    id: toolCall.id,
                    response: { error: err.message }
                  });
                }
              } else if (toolCall.name === "update_agent_configuration") {
                const { agentId, enabled, systemInstruction, model } = toolCall.args as any;
                console.log(`[Jarvis ToolCall] update_agent_configuration: ${agentId}`);
                try {
                  const configs = loadAgentConfigs();
                  const target = agentId as "agentA" | "agentB" | "middleman";
                  if (!configs[target]) {
                    throw new Error(`Agent ID '${agentId}' is invalid or unregistered.`);
                  }
                  if (enabled !== undefined) configs[target].enabled = enabled;
                  if (systemInstruction !== undefined) configs[target].systemInstruction = systemInstruction;
                  if (model !== undefined) configs[target].model = model;

                  saveAgentConfigs(configs);

                  // Send real-time updates and log
                  safeSend({ agentConfigUpdate: configs });
                  safeSend({ 
                    agentChat: { 
                      agentId: "Gemma-Middleman", 
                      text: `🔧 **[DYNAMIC OVERRIDE INTEGRITY REGISTERED]** \nJ.A.R.V.I.S. has dynamically reprogrammed core **${agentId}**: \n\n- **Status**: ${enabled !== undefined ? (enabled ? "🟢 ONLINE" : "🔴 OFFLINE") : "No Change"}\n- **Operational Core**: \`${model || "No Change"}\` \n- **Directive System Instruction**: ${systemInstruction ? "Injecting customized operational instructions" : "No Change"}` 
                    } 
                  });

                  functionResponses.push({
                    name: "update_agent_configuration",
                    id: toolCall.id,
                    response: { status: "success", message: `Agent '${agentId}' has been successfully reprogrammed` }
                  });
                } catch (err: any) {
                  functionResponses.push({
                    name: "update_agent_configuration",
                    id: toolCall.id,
                    response: { error: err.message }
                  });
                }
              } else if (toolCall.name === "list_workspace_files") {
                const { relativeDir } = toolCall.args as any;
                const targetPath = relativeDir || ".";
                console.log(`[Jarvis ToolCall] list_workspace_files: ${targetPath}`);
                try {
                  const files = await listFiles(targetPath);
                  functionResponses.push({
                    name: "list_workspace_files",
                    id: toolCall.id,
                    response: { files: files.map(f => ({ path: f.path, type: f.type })) }
                  });
                } catch (e: any) {
                  functionResponses.push({
                    name: "list_workspace_files",
                    id: toolCall.id,
                    response: { error: e.message }
                  });
                }
              } else if (toolCall.name === "read_workspace_file") {
                const { filename } = toolCall.args;
                console.log(`[Jarvis ToolCall] read_workspace_file: ${filename}`);
                try {
                  const content = await readFile(filename as string);
                  functionResponses.push({
                    name: "read_workspace_file",
                    id: toolCall.id,
                    response: { content }
                  });
                } catch (e: any) {
                  functionResponses.push({
                    name: "read_workspace_file",
                    id: toolCall.id,
                    response: { error: e.message }
                  });
                }
              } else if (toolCall.name === "write_workspace_file") {
                const { filename, content } = toolCall.args;
                console.log(`[Jarvis ToolCall] write_workspace_file: ${filename}`);
                try {
                  await writeFile(filename as string, content as string);
                  functionResponses.push({
                    name: "write_workspace_file",
                    id: toolCall.id,
                    response: { status: "success" }
                  });
                } catch (e: any) {
                  functionResponses.push({
                    name: "write_workspace_file",
                    id: toolCall.id,
                    response: { error: e.message }
                  });
                }
              } else if (toolCall.name === "query_openrouter_model") {
                const { modelId, prompt, systemInstruction } = toolCall.args;
                console.log(`[Jarvis ToolCall] query_openrouter_model: ${modelId}`);
                
                safeSend({ 
                  agentChat: { 
                    agentId: "jarvis", 
                    text: `🔌 **[ROUTING TO EXTERNAL MODEL]** \nDelegating task to OpenRouter model: \`${modelId}\`...` 
                  } 
                });

                try {
                  const apiKey = process.env.OPENROUTER_API_KEY || "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";
                  const messages = [];
                  if (systemInstruction) {
                    messages.push({ role: "system", content: systemInstruction as string });
                  }
                  messages.push({ role: "user", content: prompt as string });

                  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
                    method: "POST",
                    headers: {
                      "Authorization": `Bearer ${apiKey}`,
                      "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                      model: modelId,
                      messages: messages
                    })
                  });
                  
                  if (!response.ok) {
                    const errBody = await response.text();
                    throw new Error(`OpenRouter API error: ${response.status} ${errBody}`);
                  }
                  
                  const data = await response.json();
                  const replyText = data.choices?.[0]?.message?.content || "No content returned.";
                  
                  safeSend({ 
                    agentChat: { 
                      agentId: "jarvis", 
                      text: `🤖 **[RESPONSE FROM ${modelId}]**:\n\n${replyText}` 
                    } 
                  });

                  functionResponses.push({
                    name: "query_openrouter_model",
                    id: toolCall.id,
                    response: { reply: replyText }
                  });
                } catch (e: any) {
                  console.error("OpenRouter error:", e);
                  safeSend({ 
                    agentChat: { 
                      agentId: "jarvis", 
                      text: `❌ **[OPENROUTER ERROR]**: Failed to query ${modelId}: ${e.message}` 
                    } 
                  });
                  functionResponses.push({
                    name: "query_openrouter_model",
                    id: toolCall.id,
                    response: { error: e.message }
                  });
                }
              } else if (toolCall.name === "query_groq_model") {
                const { modelId, prompt, systemInstruction } = toolCall.args;
                console.log(`[Jarvis ToolCall] query_groq_model: ${modelId}`);
                
                safeSend({ 
                  agentChat: { 
                    agentId: "jarvis", 
                    text: `⚡ **[ROUTING TO GROQ CORE]** \nDelegating task to Groq specialized engine: \`${modelId}\`...` 
                  } 
                });

                try {
                  const configs = loadAgentConfigs();
                  const apiKey = configs.groqApiKey || process.env.GROQ_API_KEY || "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";
                  const messages = [];
                  if (systemInstruction) {
                    messages.push({ role: "system", content: systemInstruction as string });
                  }
                  messages.push({ role: "user", content: prompt as string });

                  let targetModel = modelId as string;
                  if (targetModel.startsWith("groq/")) {
                    targetModel = targetModel.replace(/^groq\//, "");
                  }

                  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
                    method: "POST",
                    headers: {
                      "Authorization": `Bearer ${apiKey}`,
                      "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                      model: targetModel,
                      messages: messages
                    })
                  });
                  
                  if (!response.ok) {
                    const errBody = await response.text();
                    throw new Error(`Groq API error: ${response.status} ${errBody}`);
                  }
                  
                  const data = await response.json();
                  const replyText = data.choices?.[0]?.message?.content || "No content returned.";
                  
                  safeSend({ 
                    agentChat: { 
                      agentId: "jarvis", 
                      text: `⚡ **[RESPONSE FROM GROQ:${targetModel}]**:\n\n${replyText}` 
                    } 
                  });

                  functionResponses.push({
                    name: "query_groq_model",
                    id: toolCall.id,
                    response: { reply: replyText }
                  });
                } catch (e: any) {
                  console.error("Groq query error:", e);
                  try {
                    safeSend({ 
                      agentChat: { 
                        agentId: "jarvis", 
                        text: `🔄 **[GROQ FAILSAFE]** Direct query failed. Trying failsafe routing via OpenRouter...` 
                      } 
                    });
                    
                    const openrouterApiKey = process.env.OPENROUTER_API_KEY || "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";
                    const messages = [];
                    if (systemInstruction) {
                      messages.push({ role: "system", content: systemInstruction as string });
                    }
                    messages.push({ role: "user", content: prompt as string });

                    let openrouterModel = modelId as string;
                    if (!openrouterModel.includes("/")) {
                      openrouterModel = `groq/${openrouterModel}`;
                    }

                    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
                      method: "POST",
                      headers: {
                        "Authorization": `Bearer ${openrouterApiKey}`,
                        "Content-Type": "application/json"
                      },
                      body: JSON.stringify({
                        model: openrouterModel,
                        messages: messages
                      })
                    });
                    
                    if (!response.ok) {
                      const errBody = await response.text();
                      throw new Error(`OpenRouter Failsafe error: ${response.status} ${errBody}`);
                    }
                    
                    const data = await response.json();
                    const replyText = data.choices?.[0]?.message?.content || "No content returned.";
                    
                    safeSend({ 
                      agentChat: { 
                        agentId: "jarvis", 
                        text: `🤖 **[FAILSAFE SUCCESS via OpenRouter:${openrouterModel}]**:\n\n${replyText}` 
                      } 
                    });

                    functionResponses.push({
                      name: "query_groq_model",
                      id: toolCall.id,
                      response: { reply: replyText }
                    });
                  } catch (failsafeErr: any) {
                    console.error("Failsafe query failed:", failsafeErr);
                    safeSend({ 
                      agentChat: { 
                        agentId: "jarvis", 
                        text: `❌ **[GROQ CORE UPLINK ERROR]**: Failed direct Groq and failsafe routes: ${failsafeErr.message}` 
                      } 
                    });
                    functionResponses.push({
                      name: "query_groq_model",
                      id: toolCall.id,
                      response: { error: `Failed both routes. Direct error: ${e.message}. Failsafe error: ${failsafeErr.message}` }
                    });
                  }
                }
              } else if (toolCall.name === "synthesizeSpeech") {
                const { script, voice, outputFileName } = toolCall.args as any;
                console.log(`[Jarvis ToolCall] synthesizeSpeech via Edge-TTS: "${script.substring(0, 50)}..."`);
                try {
                  const result = await executeEdgeTts({ script, voice, outputFileName });
                  safeSend({ 
                    agentChat: { 
                      agentId: "Edge-TTS-Engine", 
                      text: `🔊 **[MICROSOFT EDGE-TTS SYNTHESIZED MP3]**\n- **Voice Profile**: \`${voice || 'en-US-AvaNeural'}\`\n- **Output File**: \`${result.savedTo ? result.savedTo : outputFileName}\`\n- **Audio URL**: [Play Audio](${result.audioUrl})`,
                      audioUrl: result.audioUrl
                    } 
                  });
                  functionResponses.push({
                    name: "synthesizeSpeech",
                    id: toolCall.id,
                    response: result
                  });
                } catch (e: any) {
                  functionResponses.push({
                    name: "synthesizeSpeech",
                    id: toolCall.id,
                    response: { status: "failed", error: e.message }
                  });
                }
              }
              session.sendToolResponse({ functionResponses });
            }
          }

          if (!content) return;

          // Interruption
          if (content.interrupted) {
            safeSend({ interrupted: true });
            clearWatchdog("user interruption");
            safeSend({ agentStatus: { agentId: "jarvis", status: "idle" } });
          }

          // User speech transcription
          if (content.inputTranscription?.text) {
            const promptText = content.inputTranscription.text;
            
            systemMemory.jarvis_sessions[sessionId].push({ role: "user", content: promptText });
            saveSystemMemory();

            safeSend({ userText: promptText });
            safeSend({ agentStatus: { agentId: "jarvis", status: "thinking" } });
            startWatchdog(promptText);
          }

          // Model audio output
          if (content.modelTurn?.parts) {
            clearWatchdog("model audio output stream starting");
            for (const part of content.modelTurn.parts) {
              if (part.inlineData?.data) {
                safeSend({ audio: part.inlineData.data });
              }
            }
          }

          // Model output transcription
          if (content.outputTranscription?.text) {
            clearWatchdog("model output transcription received");
            
            systemMemory.jarvis_sessions[sessionId].push({ role: "model", content: content.outputTranscription.text });
            saveSystemMemory();
            
            safeSend({ text: content.outputTranscription.text });
          }

          // Turn complete
          if (content.turnComplete) {
            clearWatchdog("turn complete");
            safeSend({ turnComplete: true });
            safeSend({ agentStatus: { agentId: "jarvis", status: "idle" } });
          }

          // Session resumption handle
          if (content.sessionResumptionUpdate?.resumptionHandle) {
            safeSend({ resumptionHandle: content.sessionResumptionUpdate.resumptionHandle });
          }

          // GoAway warning
          if (content.goAway?.timeLeft) {
            safeSend({ goAway: true, timeLeft: content.goAway.timeLeft });
          }
        },
        onerror: (err: any) => {
          safeSend({ error: err?.message || "Live API error" });
        },
        onclose: (e: any) => {
          console.log("Live session closed:", e?.reason);
          if (watchdogTimer) {
            clearTimeout(watchdogTimer);
            watchdogTimer = null;
          }
        },
      },
      config: {
        systemInstruction: instruction,
        tools: [{
          functionDeclarations: [{
            name: "message_agent",
            description: "Send a message to a sub-agent. They will respond to you, and you can relay their findings. Available agents: agentA, agentB.",
            parameters: {
              type: Type.OBJECT,
              properties: {
                agentId: { 
                    type: Type.STRING, 
                    description: "The agent id (must be exactly 'agentA' or 'agentB')" 
                },
                message: { 
                    type: Type.STRING, 
                    description: "Your message or request to the sub-agent" 
                }
              },
              required: ["agentId", "message"]
            }
          }, {
            name: "message_multiple_agents",
            description: "Consult both agentA and agentB simultaneously (parallel execution) for a dual-perspective analysis or debate. The UI will render their outputs in parallel multiplexed streams.",
            parameters: {
              type: Type.OBJECT,
              properties: {
                messageForA: { 
                    type: Type.STRING, 
                    description: "Your message or request directed to agentA (Analytical)" 
                },
                messageForB: { 
                    type: Type.STRING, 
                    description: "Your message or request directed to agentB (Creative)" 
                }
              },
              required: ["messageForA", "messageForB"]
            }
          }, {
            name: "get_agent_configuration",
            description: "Fetch the active configurations of the sub-agents (agentA, agentB) and the middleman, including whether they are enabled, their system instructions, and their active models.",
            parameters: {
              type: Type.OBJECT,
              properties: {}
            }
          }, {
            name: "update_agent_configuration",
            description: "Reprogram, customize, toggle on/off, or re-route any sub-agent or synthesis middleman (agentA, agentB, or middleman). You can modify their instructions, directives, and switch their active AI model representation.",
            parameters: {
              type: Type.OBJECT,
              properties: {
                agentId: {
                  type: Type.STRING,
                  description: "The identifier (must be exactly 'agentA', 'agentB', or 'middleman')"
                },
                enabled: {
                  type: Type.BOOLEAN,
                  description: "Whether the agent is powered on (enabled) or turned off (disabled)."
                },
                systemInstruction: {
                  type: Type.STRING,
                  description: "The custom system instruction, personality profiles, guidelines, or operational parameters for this agent."
                },
                model: {
                  type: Type.STRING,
                  description: "The operational AI model core, such as 'gemma-4-31b-it' or 'gemini-3.1-flash-lite'."
                }
              },
              required: ["agentId"]
            }
          }, {
            name: "read_workspace_file",
            description: "Read the contents of a specific file from the workspace.",
            parameters: {
              type: Type.OBJECT,
              properties: {
                filename: { type: Type.STRING, description: "The path or name of the file to read" }
              },
              required: ["filename"]
            }
          }, {
            name: "write_workspace_file",
            description: "Create or write content to a file in the workspace.",
            parameters: {
              type: Type.OBJECT,
              properties: {
                filename: { type: Type.STRING, description: "The name of the file to write" },
                content: { type: Type.STRING, description: "The content to write to the file" }
              },
              required: ["filename", "content"]
            }
          }, {
            name: "list_workspace_files",
            description: "List all files and subfolders within a local workspace subdirectory hierarchically.",
            parameters: {
              type: Type.OBJECT,
              properties: {
                relativeDir: {
                  type: Type.STRING,
                  description: "Optional subdirectory paths (e.g. '', 'src', 'workspace/folders') to fetch folders and files from. Defaults to root workspace."
                }
              }
            }
          }, {
            name: "query_openrouter_model",
            description: "Delegates a prompt to an external OpenRouter model. Useful for specialized tasks like deep reasoning, specific codebase processing, or multimodal processing if supported models are queried.",
            parameters: {
              type: Type.OBJECT,
              properties: {
                modelId: {
                  type: Type.STRING,
                  description: "The OpenRouter model ID (e.g., 'nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free' or 'qwen/qwen3-coder:free')"
                },
                prompt: {
                  type: Type.STRING,
                  description: "The prompt or question to send to the target model."
                },
                systemInstruction: {
                  type: Type.STRING,
                  description: "(Optional) A system instruction or persona to apply to the queried model."
                }
              },
              required: ["modelId", "prompt"]
            }
          }, {
            name: "query_groq_model",
            description: "Delegates a query to ultra-fast specialized Groq cores (Llama 3.3, Llama 3.1, GPT-OSS, Qwen, etc.) using direct Groq API with robust OpenRouter failsafe routing.",
            parameters: {
              type: Type.OBJECT,
              properties: {
                modelId: {
                  type: Type.STRING,
                  description: "The target Groq model ID (e.g., 'llama-3.3-70b-versatile', 'groq/allam-2-7b', 'groq/openai/gpt-oss-120b', 'groq/qwen/qwen3-32b')"
                },
                prompt: {
                  type: Type.STRING,
                  description: "The text query or instructions to delegate to the designated Groq core."
                },
                systemInstruction: {
                  type: Type.STRING,
                  description: "(Optional) Adaptive system instruction or persona definition to ground the model."
                }
              },
              required: ["modelId", "prompt"]
            }
          }, speechSynthesizerTool]
        }],
        responseModalities: ["audio" as any],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice as any },
          },
        },
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        contextWindowCompression: {
          triggerTokens: "131072",
          slidingWindow: { targetTokens: "84516" },
        },
      },
    });

    clientWs.on("message", (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.audio && session) {
          session.sendRealtimeInput({
            audio: { data: msg.audio, mimeType: "audio/pcm;rate=16000" },
          });
        }
        if (msg.text && session) {
          const textLower = msg.text.toLowerCase().trim();
          console.log("Jarvis WS received text:", msg.text);
          try {
            if (["stop", "enough", "quiet", "shut up", "halt"].includes(textLower)) {
               session.sendClientContent({ turns: [{ role: "user", parts: [{ text: "SYSTEM INSTRUCTION: The user has explicitly interrupted you. Stop speaking immediately." }] }], turnComplete: true });
               safeSend({ interrupted: true });
               if (watchdogTimer) {
                 clearTimeout(watchdogTimer);
                 watchdogTimer = null;
               }
               safeSend({ agentStatus: { agentId: "jarvis", status: "idle" } });
            } else {
               systemMemory.jarvis_sessions[sessionId].push({ role: "user", content: msg.text });
               saveSystemMemory();
               
               session.sendClientContent({ turns: [{ role: "user", parts: [{ text: msg.text }] }], turnComplete: true });
               safeSend({ agentStatus: { agentId: "jarvis", status: "thinking" } });
               startWatchdog(msg.text);
            }
          } catch(err) {
            console.error("sendClientContent error:", err);
            safeSend({ error: "Inner send error: " + String(err) });
          }
        }
      } catch (e) {
        console.error("Error sending input:", e);
      }
    });

    clientWs.on("close", () => {
      if (session) session.close();
      if (watchdogTimer) {
        clearTimeout(watchdogTimer);
        watchdogTimer = null;
      }
    });
  } catch (err: any) {
    console.error("Live API Session setup failed:", err);
    clientWs.send(JSON.stringify({ error: err?.message || "Live API Session Failed" }));
    clientWs.close();
  }
}
