import React, { useState, useEffect } from 'react';
import ChatPanel from './components/ChatPanel';
import SettingsPanel from './components/SettingsPanel';
import AgentLogsPanel from './components/AgentLogsPanel';
import EdgeTtsStudioModal from './components/EdgeTtsStudioModal';
import WorkspaceManagerModal from './components/WorkspaceManagerModal';
import SimplifiedPipelineDemo from './components/SimplifiedPipelineDemo';
import ModeHeaderSwitcher from './components/ModeHeaderSwitcher';
import SubtextDiscussionStudio from './components/SubtextDiscussionStudio';
import { AppMode } from './types/discussion';
import { StoryBible, createDefaultStoryBible } from './types/storyBible';
import { 
  Settings, TerminalSquare, Volume2, 
  MessageSquare, Sparkles, Sun, Moon, Cpu, ChevronRight, Menu, X, ChevronLeft, LayoutDashboard, Radio, HardDrive, Zap,
  Users, Trophy, FileText, Brain
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';

export default function App() {
  const [appMode, setAppMode] = useState<AppMode>('hardcore');
  const [storyBible, setStoryBible] = useState<StoryBible>(() => createDefaultStoryBible());
  const [showTtsStudio, setShowTtsStudio] = useState(false);
  const [showWorkspaceModal, setShowWorkspaceModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'pipeline' | 'phase1' | 'phase2' | 'phase3' | 'phase4' | 'phase5' | 'chat' | 'settings' | 'logs'>('phase1');
  const [currentPipelinePhase, setCurrentPipelinePhase] = useState<1 | 2 | 3 | 4 | 5>(1);
  const [messages, setMessages] = useState<import('./types/index').ChatMessage[]>([]);
  const [agentStatuses, setAgentStatuses] = useState<Record<string, 'active' | 'idle' | 'offline' | 'working' | 'thinking' | 'preparing' | 'sending'>>({
    jarvis: 'idle',
    agentA: 'idle',
    agentB: 'idle'
  });

  useEffect(() => {
    fetch('/api/story-bible')
      .then(res => res.json())
      .then(data => {
        if (data && data.version) {
          setStoryBible(data);
        }
      })
      .catch(err => console.warn('[App] Story Bible load warning:', err));
  }, []);

  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showSideChat, setShowSideChat] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem('app-theme');
    return saved === 'light' ? 'light' : 'dark';
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('app-theme', theme);
  }, [theme]);

  useEffect(() => {
    // Clear legacy leaked default keys from localStorage if present
    const keyA = localStorage.getItem('agentA_text_key');
    const keyB = localStorage.getItem('agentB_text_key');
    if (keyA && keyA.startsWith('AIzaSyAmTIhQ')) {
      localStorage.removeItem('agentA_text_key');
    }
    if (keyB && keyB.startsWith('AIzaSyBqtio3')) {
      localStorage.removeItem('agentB_text_key');
    }

    const handleToggleCopilot = () => {
      setShowSideChat(prev => !prev);
    };
    window.addEventListener('toggle_jarvis_copilot', handleToggleCopilot);
    return () => {
      window.removeEventListener('toggle_jarvis_copilot', handleToggleCopilot);
    };
  }, []);

  const tabMeta: Record<string, { 
    title: string; 
    category: string; 
    icon: any; 
    color: string; 
    bgColor: string; 
    activeBg: string; 
    borderColor: string; 
    badgeBg: string; 
    badgeText: string; 
  }> = {
    pipeline: {
      title: 'Unified Production Pipeline',
      category: 'Core System',
      icon: Zap,
      color: 'text-amber-300',
      bgColor: 'bg-amber-500/20',
      activeBg: 'bg-gradient-to-r from-amber-500 via-emerald-500 to-teal-500 text-slate-950 font-black',
      borderColor: 'border-amber-400/60',
      badgeBg: 'bg-amber-500/20',
      badgeText: 'text-amber-300'
    },
    phase1: {
      title: 'Phase 1: Project Intake',
      category: 'Production Pipeline',
      icon: Zap,
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/15',
      activeBg: 'bg-amber-500 text-slate-950 font-black',
      borderColor: 'border-amber-400/60',
      badgeBg: 'bg-amber-500/20',
      badgeText: 'text-amber-300'
    },
    phase2: {
      title: 'Phase 2: Personas (Character Bibles)',
      category: 'Production Pipeline',
      icon: Users,
      color: 'text-sky-400',
      bgColor: 'bg-sky-500/15',
      activeBg: 'bg-sky-500 text-slate-950 font-black',
      borderColor: 'border-sky-400/60',
      badgeBg: 'bg-sky-500/20',
      badgeText: 'text-sky-300'
    },
    phase3: {
      title: 'Phase 3: Scene Idea Matrix',
      category: 'Production Pipeline',
      icon: Trophy,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/15',
      activeBg: 'bg-purple-500 text-white font-black',
      borderColor: 'border-purple-400/60',
      badgeBg: 'bg-purple-500/20',
      badgeText: 'text-purple-300'
    },
    phase4: {
      title: 'Phase 4: Raw Story & Script (CPSD Blueprint)',
      category: 'Production Pipeline',
      icon: FileText,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/15',
      activeBg: 'bg-emerald-500 text-slate-950 font-black',
      borderColor: 'border-emerald-400/60',
      badgeBg: 'bg-emerald-500/20',
      badgeText: 'text-emerald-300'
    },
    chat: { 
      title: 'AI Assistant Command', 
      category: 'Agentic Workspace', 
      icon: MessageSquare,
      color: 'text-sky-400',
      bgColor: 'bg-sky-500/15',
      activeBg: 'bg-sky-500 text-slate-950',
      borderColor: 'border-sky-500/40',
      badgeBg: 'bg-sky-500/20',
      badgeText: 'text-sky-300'
    },
    logs: { 
      title: 'Terminal Logs & Telemetry', 
      category: 'Agentic Workspace', 
      icon: TerminalSquare,
      color: 'text-indigo-400',
      bgColor: 'bg-indigo-500/15',
      activeBg: 'bg-indigo-500 text-white',
      borderColor: 'border-indigo-500/40',
      badgeBg: 'bg-indigo-500/20',
      badgeText: 'text-indigo-300'
    },
    settings: { 
      title: 'System Configuration', 
      category: 'System Controls', 
      icon: Settings,
      color: 'text-pink-400',
      bgColor: 'bg-pink-500/15',
      activeBg: 'bg-pink-500 text-white',
      borderColor: 'border-pink-500/40',
      badgeBg: 'bg-pink-500/20',
      badgeText: 'text-pink-300'
    },
  };

  const currentTab = tabMeta[activeTab] || tabMeta.pipeline;

  return (
    <div className="h-screen w-full bg-[#080c14] text-slate-100 flex overflow-hidden font-sans relative select-none">
      {/* TABLER VERTICAL SIDEBAR NAVIGATION (navbar-vertical) */}
      <aside 
        className={`${
          sidebarCollapsed ? 'w-14' : 'w-60'
        } ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        } fixed md:relative z-40 h-full bg-[#0d1322] border-r border-white/10 flex flex-col justify-between transition-all duration-200 shrink-0 shadow-xl`}
      >
        {/* Brand Header */}
        <div className="h-11 border-b border-white/10 px-3 flex items-center justify-between shrink-0 bg-[#090d16]">
          <div className="flex items-center gap-2 overflow-hidden">
            <div className="w-7 h-7 rounded-md bg-gradient-to-br from-sky-500/20 via-purple-500/20 to-emerald-500/20 border border-sky-400/40 flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(14,165,233,0.3)]">
              <Cpu className="w-3.5 h-3.5 text-sky-400" />
            </div>
            {!sidebarCollapsed && (
              <div className="flex flex-col min-w-0">
                <span className="font-extrabold text-xs tracking-wider text-white truncate flex items-center gap-1">
                  J.A.R.V.I.S. <span className="text-[9px] font-bold px-1.5 py-0.1 rounded bg-gradient-to-r from-amber-500/20 via-emerald-500/20 to-purple-500/20 text-emerald-300 border border-emerald-500/30">v2.0</span>
                </span>
                <span className="text-[9px] text-slate-400 font-medium truncate">Agentic Story Studio</span>
              </div>
            )}
          </div>

          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="hidden md:flex p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title={sidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          >
            <ChevronLeft className={`w-3.5 h-3.5 transition-transform duration-200 ${sidebarCollapsed ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {/* Sidebar Nav Items */}
        <div className="flex-1 overflow-y-auto p-2 space-y-4 custom-scrollbar">
          {/* Production Pipeline Phases */}
          <div className="space-y-1">
            {!sidebarCollapsed && (
              <p className="px-2 text-[9px] font-extrabold uppercase tracking-widest text-amber-400/80 mb-1 flex items-center justify-between">
                <span>Production Pipeline</span>
                <span className="text-[8px] bg-amber-500/20 text-amber-300 px-1 rounded border border-amber-500/30 font-bold">4 PHASES</span>
              </p>
            )}

            <button
              id="tab-phase1-btn"
              onClick={() => {
                setCurrentPipelinePhase(1);
                setActiveTab('phase1');
                setMobileMenuOpen(false);
              }}
              className={`w-full px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center justify-between transition-all cursor-pointer border ${
                activeTab === 'phase1' || (activeTab === 'pipeline' && currentPipelinePhase === 1)
                  ? 'bg-amber-500 text-slate-950 font-black border-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                  : 'text-amber-300/90 hover:text-amber-200 bg-amber-500/10 hover:bg-amber-500/20 border-amber-500/30'
              }`}
              title="Phase 1: Project Intake"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Zap className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'phase1' ? 'text-slate-950' : 'text-amber-400'}`} />
                {!sidebarCollapsed && <span className="truncate font-bold">Phase 1: Intake</span>}
              </div>
              {!sidebarCollapsed && (
                <span className={`text-[8px] font-extrabold px-1 rounded border ${
                  activeTab === 'phase1' ? 'bg-slate-950/30 text-slate-950 border-slate-950/40' : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                }`}>
                  P1
                </span>
              )}
            </button>

            <button
              id="tab-phase2-btn"
              onClick={() => {
                setCurrentPipelinePhase(2);
                setActiveTab('phase2');
                setMobileMenuOpen(false);
              }}
              className={`w-full px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center justify-between transition-all cursor-pointer border ${
                activeTab === 'phase2' || (activeTab === 'pipeline' && currentPipelinePhase === 2)
                  ? 'bg-sky-500 text-slate-950 font-black border-sky-300 shadow-[0_0_12px_rgba(14,165,233,0.4)]'
                  : 'text-sky-300/90 hover:text-sky-200 bg-sky-500/10 hover:bg-sky-500/20 border-sky-500/30'
              }`}
              title="Phase 2: Personas (Character Bibles)"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Users className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'phase2' ? 'text-slate-950' : 'text-sky-400'}`} />
                {!sidebarCollapsed && <span className="truncate font-bold">Phase 2: Personas</span>}
              </div>
              {!sidebarCollapsed && (
                <span className={`text-[8px] font-extrabold px-1 rounded border ${
                  activeTab === 'phase2' ? 'bg-slate-950/30 text-slate-950 border-slate-950/40' : 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                }`}>
                  P2
                </span>
              )}
            </button>

            <button
              id="tab-phase3-btn"
              onClick={() => {
                setCurrentPipelinePhase(3);
                setActiveTab('phase3');
                setMobileMenuOpen(false);
              }}
              className={`w-full px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center justify-between transition-all cursor-pointer border ${
                activeTab === 'phase3' || (activeTab === 'pipeline' && currentPipelinePhase === 3)
                  ? 'bg-purple-500 text-white font-black border-purple-300 shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                  : 'text-purple-300/90 hover:text-purple-200 bg-purple-500/10 hover:bg-purple-500/20 border-purple-500/30'
              }`}
              title="Phase 3: Scene Idea Matrix"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Trophy className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'phase3' ? 'text-white' : 'text-purple-400'}`} />
                {!sidebarCollapsed && <span className="truncate font-bold">Phase 3: Scene Matrix</span>}
              </div>
              {!sidebarCollapsed && (
                <span className={`text-[8px] font-extrabold px-1 rounded border ${
                  activeTab === 'phase3' ? 'bg-slate-950/30 text-white border-purple-400/40' : 'bg-purple-500/20 text-purple-300 border-purple-500/40'
                }`}>
                  P3
                </span>
              )}
            </button>

            <button
              id="tab-phase4-btn"
              onClick={() => {
                setCurrentPipelinePhase(4);
                setActiveTab('phase4');
                setMobileMenuOpen(false);
              }}
              className={`w-full px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center justify-between transition-all cursor-pointer border ${
                activeTab === 'phase4' || (activeTab === 'pipeline' && currentPipelinePhase === 4)
                  ? 'bg-emerald-500 text-slate-950 font-black border-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.4)]'
                  : 'text-emerald-300/90 hover:text-emerald-200 bg-emerald-500/10 hover:bg-emerald-500/20 border-emerald-500/30'
              }`}
              title="Phase 4: Raw Story & Script (CPSD)"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <FileText className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'phase4' ? 'text-slate-950' : 'text-emerald-400'}`} />
                {!sidebarCollapsed && <span className="truncate font-bold">Phase 4: CPSD & Script</span>}
              </div>
              {!sidebarCollapsed && (
                <span className={`text-[8px] font-extrabold px-1 rounded border ${
                  activeTab === 'phase4' ? 'bg-slate-950/30 text-slate-950 border-slate-950/40' : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                }`}>
                  P4
                </span>
              )}
            </button>

            <button
              id="tab-phase5-btn"
              onClick={() => {
                setCurrentPipelinePhase(5);
                setActiveTab('phase5');
                setMobileMenuOpen(false);
              }}
              className={`w-full px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center justify-between transition-all cursor-pointer border ${
                activeTab === 'phase5' || (activeTab === 'pipeline' && currentPipelinePhase === 5)
                  ? 'bg-indigo-500 text-slate-950 font-black border-indigo-300 shadow-[0_0_12px_rgba(99,102,241,0.4)]'
                  : 'text-indigo-300/90 hover:text-indigo-200 bg-indigo-500/10 hover:bg-indigo-500/20 border-indigo-500/30'
              }`}
              title="Phase 5: Cinematic Script"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <FileText className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'phase5' ? 'text-slate-950' : 'text-indigo-400'}`} />
                {!sidebarCollapsed && <span className="truncate font-bold">Phase 5: Script Engine</span>}
              </div>
              {!sidebarCollapsed && (
                <span className={`text-[8px] font-extrabold px-1 rounded border ${
                  activeTab === 'phase5' ? 'bg-slate-950/30 text-slate-950 border-slate-950/40' : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40'
                }`}>
                  P5
                </span>
              )}
            </button>
          </div>

          {/* Group 2: Agentic Workspace */}
          <div className="space-y-1">
            {!sidebarCollapsed && (
              <p className="px-2 text-[9px] font-extrabold uppercase tracking-widest text-sky-400/80 mb-1">
                Agentic Workspace
              </p>
            )}

            <button
              id="tab-chat-btn"
              onClick={() => { setActiveTab('chat'); setMobileMenuOpen(false); }}
              className={`w-full px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-2.5 transition-all cursor-pointer border ${
                activeTab === 'chat'
                  ? 'bg-sky-500 text-slate-950 font-extrabold border-sky-400 shadow-[0_0_10px_rgba(14,165,233,0.35)]'
                  : 'text-sky-300/80 hover:text-sky-200 bg-sky-500/5 hover:bg-sky-500/15 border-sky-500/20'
              }`}
              title="AI Assistant Command Workspace"
            >
              <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'chat' ? 'text-slate-950' : 'text-sky-400'}`} />
              {!sidebarCollapsed && <span className="truncate">AI Assistant</span>}
            </button>

            <button
              id="tab-logs-btn"
              onClick={() => { setActiveTab('logs'); setMobileMenuOpen(false); }}
              className={`w-full px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-2.5 transition-all cursor-pointer border ${
                activeTab === 'logs'
                  ? 'bg-indigo-500 text-white font-extrabold border-indigo-400 shadow-[0_0_10px_rgba(99,102,241,0.35)]'
                  : 'text-indigo-300/80 hover:text-indigo-200 bg-indigo-500/5 hover:bg-indigo-500/15 border-indigo-500/20'
              }`}
              title="Terminal Logs"
            >
              <TerminalSquare className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'logs' ? 'text-white' : 'text-indigo-400'}`} />
              {!sidebarCollapsed && <span className="truncate">Terminal Logs</span>}
            </button>

            <button
              id="sidebar-workspace-btn"
              onClick={() => { setShowWorkspaceModal(true); setMobileMenuOpen(false); }}
              className="w-full px-2.5 py-1.5 rounded-md text-xs font-semibold text-amber-300/90 hover:text-amber-100 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 flex items-center gap-2.5 transition-all cursor-pointer"
              title="Workspace Files & Cache Manager"
            >
              <HardDrive className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              {!sidebarCollapsed && <span className="truncate">Workspace Files</span>}
            </button>
          </div>

          {/* Group 3: System Utilities */}
          <div className="space-y-1">
            {!sidebarCollapsed && (
              <p className="px-2 text-[9px] font-extrabold uppercase tracking-widest text-pink-400/80 mb-1">
                System Utilities
              </p>
            )}

            <button
              id="tab-edge-tts-btn"
              onClick={() => setShowTtsStudio(true)}
              className="w-full px-2.5 py-1.5 rounded-md text-xs font-semibold text-rose-300/90 hover:text-rose-100 bg-rose-500/5 hover:bg-rose-500/15 border border-rose-500/20 flex items-center gap-2.5 transition-all cursor-pointer"
              title="Neural TTS Studio"
            >
              <Volume2 className="w-3.5 h-3.5 text-rose-400 shrink-0" />
              {!sidebarCollapsed && <span className="truncate">Neural TTS Studio</span>}
            </button>

            <button
              id="tab-settings-btn"
              onClick={() => { setActiveTab('settings'); setMobileMenuOpen(false); }}
              className={`w-full px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-2.5 transition-all cursor-pointer border ${
                activeTab === 'settings'
                  ? 'bg-pink-500 text-white font-extrabold border-pink-400 shadow-[0_0_10px_rgba(236,72,153,0.35)]'
                  : 'text-pink-300/80 hover:text-pink-200 bg-pink-500/5 hover:bg-pink-500/15 border-pink-500/20'
              }`}
              title="Settings & Configuration"
            >
              <Settings className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'settings' ? 'text-white' : 'text-pink-400'}`} />
              {!sidebarCollapsed && <span className="truncate">Settings & Config</span>}
            </button>
          </div>
        </div>

        {/* Sidebar Footer / System Status */}
        <div className="p-2 border-t border-white/10 bg-[#090d16] shrink-0">
          {!sidebarCollapsed ? (
            <div className="flex items-center justify-between gap-2 bg-[#0d1424] p-2 rounded-md border border-emerald-500/20">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                <div className="flex flex-col min-w-0">
                  <span className="text-[10px] font-bold text-slate-200 truncate">J.A.R.V.I.S. Core</span>
                  <span className="text-[8px] text-emerald-400 font-bold">Neural Online</span>
                </div>
              </div>

              <button
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                title="Toggle Theme"
              >
                {theme === 'dark' ? <Sun className="w-3 h-3 text-amber-400" /> : <Moon className="w-3 h-3 text-sky-400" />}
              </button>
            </div>
          ) : (
            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="w-full py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center cursor-pointer"
              title="Toggle Theme"
            >
              {theme === 'dark' ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-sky-400" />}
            </button>
          )}
        </div>
      </aside>

      {/* PAGE BODY & CONTENT AREA */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative min-w-0">
        {/* TABLER PAGE HEADER (page-header) */}
        <header className="h-11 border-b border-white/10 bg-[#0c1220] px-3 flex items-center justify-between shrink-0 z-20 shadow-sm">
          {/* Breadcrumbs & Title with Color-coded Accents */}
          <div className="flex items-center gap-2 min-w-0">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-1 rounded bg-slate-800 text-slate-200 hover:bg-slate-700 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>

            <div className="flex items-center gap-1.5 text-xs min-w-0">
              <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${currentTab.badgeBg} ${currentTab.badgeText} ${currentTab.borderColor}`}>
                {currentTab.category}
              </span>
              <ChevronRight className="w-3 h-3 text-slate-500 shrink-0" />
              <span className={`font-extrabold text-xs truncate flex items-center gap-1.5 ${currentTab.color}`}>
                <currentTab.icon className={`w-3.5 h-3.5 ${currentTab.color} shrink-0`} />
                {currentTab.title}
              </span>
            </div>
          </div>

          {/* Top Page Header Actions & Mode Switcher */}
          <div className="flex items-center gap-2">
            {/* Hardcore vs Discussion Mode Switcher */}
            <ModeHeaderSwitcher
              mode={appMode}
              onModeChange={(newMode) => {
                setAppMode(newMode);
                if (newMode === 'discussion') {
                  // Ensure story bible is refreshed
                  fetch('/api/story-bible')
                    .then(res => res.json())
                    .then(data => { if (data && data.version) setStoryBible(data); });
                }
              }}
            />

            {/* Workspace Files Manager Button */}
            <button
              id="header-workspace-modal-btn"
              onClick={() => setShowWorkspaceModal(true)}
              className="px-2.5 py-1 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-extrabold flex items-center gap-1.5 cursor-pointer transition-all"
              title="Open Workspace & File Manager"
            >
              <HardDrive className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Workspace</span>
            </button>

            {/* AI Assistant Command Workspace Button */}
            <button
              onClick={() => setActiveTab('chat')}
              className={`px-2.5 py-1 rounded transition-colors cursor-pointer flex items-center gap-1.5 text-[11px] font-extrabold border ${
                activeTab === 'chat' 
                  ? 'bg-sky-500 text-slate-950 border-sky-400 shadow-[0_0_10px_rgba(14,165,233,0.4)]' 
                  : 'bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 border-sky-500/30'
              }`}
              title="Open AI Workspace Chat"
            >
              <MessageSquare className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden sm:inline">AI Workspace Chat</span>
            </button>
          </div>
        </header>

        {/* WORKSPACE MAIN VIEWPORT */}
        <main className="flex-1 relative overflow-hidden bg-[#080c14] flex">
          <div className="flex-1 relative overflow-hidden">
            {appMode === 'discussion' ? (
              <SubtextDiscussionStudio
                storyBible={storyBible}
                onUpdateStoryBible={setStoryBible}
                onSwitchToHardcoreMode={() => setAppMode('hardcore')}
              />
            ) : (
              <>
                {['pipeline', 'phase1', 'phase2', 'phase3', 'phase4', 'phase5'].includes(activeTab) && (
                  <SimplifiedPipelineDemo 
                    activePhase={currentPipelinePhase} 
                    onPhaseChange={(p) => {
                      setCurrentPipelinePhase(p);
                      setActiveTab(`phase${p}` as any);
                    }} 
                    onAttachToMainSystem={() => setShowSideChat(true)}
                  />
                )}
                {activeTab === 'chat' && <ChatPanel activeTab={activeTab} messages={messages} setMessages={setMessages} setAgentStatuses={setAgentStatuses} />}
                {activeTab === 'settings' && <SettingsPanel theme={theme} setTheme={setTheme} />}
                {activeTab === 'logs' && <AgentLogsPanel messages={messages} />}
              </>
            )}
          </div>

          {/* AI Side Drawer */}
          <AnimatePresence>
            {showSideChat && (
              <motion.div
                initial={{ x: '100%', opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: '100%', opacity: 0 }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className="w-96 border-l border-white/10 bg-[#0d1322] shadow-2xl z-40 flex flex-col h-full shrink-0"
              >
                <div className="h-9 border-b border-white/10 flex items-center justify-between px-3 shrink-0 bg-[#090d16]">
                  <div className="flex items-center gap-1.5">
                    <MessageSquare className="w-3.5 h-3.5 text-sky-400" />
                    <span className="font-bold text-xs text-slate-100">J.A.R.V.I.S. Copilot Assistant</span>
                  </div>
                  <button 
                    onClick={() => setShowSideChat(false)}
                    className="p-1 rounded text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer text-xs font-bold"
                  >
                    ✕
                  </button>
                </div>
                <div className="flex-1 overflow-hidden">
                  <ChatPanel activeTab={activeTab} messages={messages} setMessages={setMessages} setAgentStatuses={setAgentStatuses} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* Floating Copilot Launcher when Drawer is closed & not on chat tab */}
      {!showSideChat && activeTab !== 'chat' && (
        <button
          onClick={() => {
            setShowSideChat(true);
          }}
          className="fixed bottom-4 right-4 h-11 px-4 bg-gradient-to-r from-sky-500 via-indigo-500 to-purple-500 text-white rounded-full flex items-center gap-2 shadow-[0_0_20px_rgba(14,165,233,0.5)] hover:scale-105 transition-all z-50 cursor-pointer font-bold text-xs border border-sky-300/40"
          title="Toggle Copilot Drawer"
        >
          <MessageSquare className="w-4 h-4 animate-bounce text-sky-200" />
          <span>J.A.R.V.I.S. Copilot</span>
        </button>
      )}

      {/* TTS & Workspace Modals */}
      <AnimatePresence>
        {showTtsStudio && (
          <EdgeTtsStudioModal key="tts-studio-modal" onClose={() => setShowTtsStudio(false)} />
        )}
      </AnimatePresence>

      <WorkspaceManagerModal
        isOpen={showWorkspaceModal}
        onClose={() => setShowWorkspaceModal(false)}
      />
    </div>
  );
}
