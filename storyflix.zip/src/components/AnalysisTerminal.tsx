import React, { useState, useEffect, useRef } from 'react';
import { 
  UploadCloud, 
  FileText, 
  Trash2, 
  RefreshCw, 
  Cpu, 
  Save, 
  Plus, 
  MessageSquare, 
  PanelRightOpen, 
  PanelRightClose, 
  X, 
  Folder, 
  FolderPlus, 
  ChevronRight, 
  CornerLeftUp 
} from 'lucide-react';

interface AnalysisTerminalProps {
  onAnalyzeRequest?: (filename: string) => void;
}

interface FileMetadata {
  name: string;
  path: string;
  isDirectory: boolean;
  size: number;
  updatedAt: string;
}

export default function AnalysisTerminal({ onAnalyzeRequest }: AnalysisTerminalProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [isFocused, setIsFocused] = useState(false); // Used for full-screen text editor
  const [files, setFiles] = useState<FileMetadata[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [currentPath, setCurrentPath] = useState<string>('');

  const [showNewFolderInput, setShowNewFolderInput] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [previewContent, setPreviewContent] = useState<{name: string, content: string, isNew?: boolean} | null>(null);

  const fetchFiles = async (subdir: string = currentPath) => {
    setIsLoading(true);
    try {
      const res = await fetch(`/api/files?path=${encodeURIComponent(subdir)}`);
      if (res.ok) {
        const data = await res.json();
        setFiles(data.files || []);
        setCurrentPath(subdir);
      }
    } catch(e) {
      console.error("Failed to fetch files", e);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePreview = async (filePath: string) => {
    try {
      const res = await fetch(`/api/files/content/${encodeURIComponent(filePath)}`);
      if (res.ok) {
        const data = await res.json();
        setPreviewContent({ name: filePath, content: data.content });
        setIsFocused(true); // Open in full screen editor
      }
    } catch(e) {
      console.error("Failed to preview", e);
    }
  };

  const handleSave = async () => {
    if (!previewContent || !previewContent.name.trim()) return;
    try {
      let finalFilename = previewContent.name;
      if (previewContent.isNew) {
        finalFilename = currentPath ? `${currentPath}/${previewContent.name}` : previewContent.name;
      }

      await fetch('/api/files/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: finalFilename, content: previewContent.content })
      });
      setPreviewContent({ name: finalFilename, content: previewContent.content, isNew: false });
      setIsFocused(false);
      
      fetchFiles(currentPath);
    } catch (e) {
      console.error("Failed to save", e);
    }
  };

  const handleCreateFolder = async () => {
    if (!newFolderName.trim()) return;
    try {
      const targetDirPath = currentPath ? `${currentPath}/${newFolderName}` : newFolderName;
      const res = await fetch('/api/files/folder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: targetDirPath })
      });
      if (res.ok) {
        setNewFolderName('');
        setShowNewFolderInput(false);
        fetchFiles(currentPath);
      }
    } catch (e) {
      console.error("Failed to create folder", e);
    }
  };

  useEffect(() => {
    fetchFiles('');
  }, []);

  const uploadFile = async (file: File) => {
    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      await fetch(`/api/files/upload?path=${encodeURIComponent(currentPath)}`, {
        method: 'POST',
        body: formData
      });
      fetchFiles(currentPath);
    } catch(e) {
      console.error("Upload failed", e);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files || event.target.files.length === 0) return;
    uploadFile(event.target.files[0]);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      uploadFile(e.dataTransfer.files[0]);
    }
  };

  const handleDelete = async (filePath: string) => {
    try {
      await fetch(`/api/files/${encodeURIComponent(filePath)}`, {
        method: 'DELETE'
      });
      fetchFiles(currentPath);
    } catch(e) {
      console.error("Delete failed", e);
    }
  };

  const handleBreadcrumbClick = (index: number) => {
    const segments = currentPath.split('/').filter(Boolean);
    const targetPath = segments.slice(0, index + 1).join('/');
    fetchFiles(targetPath);
  };

  const segments = currentPath.split('/').filter(Boolean);

  // Full Screen Editor Overlay
  if (isFocused && previewContent) {
    return (
      <div className="absolute inset-0 z-50 bg-bg-slate text-slate-light flex flex-col p-6 animate-in fade-in duration-300">
        <div className="flex justify-between items-center mb-6 pb-2 border-b border-tab-blue/30">
          <div className="flex flex-col">
            <h2 className="text-xl font-bold tracking-tight flex items-center gap-2 text-slate-light">
              <FileText className="w-5 h-5 text-slate-light" />
              {previewContent.isNew ? 'New File' : previewContent.name}
            </h2>
            <p className="text-sm text-slate-light/70">{previewContent.isNew ? 'Unsaved Text File' : 'Editing File'}</p>
          </div>
          
          <div className="flex items-center gap-3">
             <button 
                onClick={handleSave}
                className="flex items-center gap-2 px-4 py-2 bg-tab-blue text-text-black hover:bg-[#60a5fa] rounded-md uppercase text-xs font-bold transition-colors shadow-[0_0_8px_rgba(59,130,246,0.3)]"
              >
                <Save className="w-4 h-4" /> Save File
              </button>
              {onAnalyzeRequest && !previewContent.isNew && (
                <button 
                  onClick={() => {
                    onAnalyzeRequest(previewContent.name);
                    setIsFocused(false);
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-[#f1f5f9] text-text-black hover:bg-[#ffffff] rounded-md uppercase text-xs font-bold transition-colors"
                >
                  <MessageSquare className="w-4 h-4" /> Ask J.A.R.V.I.S.
                </button>
              )}
              <button 
                onClick={() => setIsFocused(false)}
                className="flex items-center gap-2 px-4 py-2 bg-bg-dark-slate hover:bg-bg-dark-slate text-slate-light rounded-md uppercase text-xs font-bold transition-colors border border-tab-blue/30"
              >
                <X className="w-4 h-4" /> Close
              </button>
          </div>
        </div>

        {previewContent.isNew && (
          <div className="mb-4 flex items-center gap-4">
            <label className="text-xs text-slate-light/70 font-mono">FILENAME</label>
            <input 
              value={previewContent.name} 
              onChange={e => setPreviewContent({...previewContent, name: e.target.value})}
              placeholder="e.g. index.html, script.py"
              className="bg-bg-dark-slate border border-tab-blue/40 text-sm font-sans text-slate-light px-3 py-2 rounded flex-1 max-w-md focus:outline-none focus:border-[#f1f5f9]"
            />
          </div>
        )}

        <textarea 
          className="flex-1 w-full bg-bg-dark-slate border border-tab-blue/30 focus:border-[#f1f5f9] transition-colors p-6 rounded-xl text-sm leading-relaxed text-slate-light font-sans resize-none focus:outline-none shadow-inner"
          value={previewContent.content}
          onChange={e => setPreviewContent({...previewContent, content: e.target.value})}
          placeholder="Start typing..."
          spellCheck={false}
        />
      </div>
    );
  }

  return (
    <div className={`relative h-full flex shrink-0 transition-all duration-300 ease-in-out ${isOpen ? 'w-80 border-l border-tab-blue/30 bg-bg-dark-slate' : 'w-0 border-l-0'}`}>
      {/* Sidebar Toggle Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="absolute top-4 -left-8 z-40 bg-bg-dark-slate border border-tab-blue/30 border-r-0 rounded-l-md p-1.5 hover:bg-bg-slate text-slate-light transition-colors cursor-pointer"
        title={isOpen ? "Collapse Panel" : "Expand Panel"}
      >
        {isOpen ? <PanelRightClose className="w-4 h-4" /> : <PanelRightOpen className="w-4 h-4" />}
      </button>

      <div className={`flex flex-col h-full w-80 overflow-hidden ${isOpen ? 'opacity-100' : 'opacity-0'}`}>
        <div className="h-11 border-b border-tab-blue/30 flex items-center px-4 justify-between shrink-0 select-none">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-slate-light" />
            <h3 className="text-[10px] font-sans text-slate-light tracking-widest font-bold">ANALYSIS TERMINAL</h3>
          </div>
          <button onClick={() => fetchFiles(currentPath)} className="text-slate-light/60 hover:text-slate-light transition-colors" title="Refresh Files">
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Dynamic Breadcrumbs */}
        <div className="bg-bg-slate px-4 py-2 border-b border-tab-blue/30 text-[10px] font-sans text-slate-light/70 flex align-middle items-center flex-wrap gap-1.5 overflow-x-auto select-none">
          <span 
            className="hover:text-slate-light cursor-pointer transition-colors font-bold" 
            onClick={() => fetchFiles('')}
          >
            ~
          </span>
          {segments.map((seg, idx) => (
            <React.Fragment key={idx}>
              <ChevronRight className="w-2.5 h-2.5 text-slate-light/40 shrink-0" />
              <span 
                className={`hover:text-slate-light cursor-pointer transition-colors ${idx === segments.length - 1 ? 'text-slate-light font-bold' : ''}`}
                onClick={() => handleBreadcrumbClick(idx)}
              >
                {seg}
              </span>
            </React.Fragment>
          ))}
        </div>

        <div className="flex-1 overflow-auto p-4 flex flex-col gap-4">
          {/* Dropzone Area */}
          <div 
            className="border-2 border-dashed border-tab-blue/40 rounded-xl p-5 flex flex-col items-center justify-center gap-2 text-center hover:border-[#f1f5f9] hover:bg-bg-slate/50 transition-all cursor-pointer relative"
            onClick={() => fileInputRef.current?.click()}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
          >
            <UploadCloud className="w-7 h-7 text-slate-light" />
            <div>
              <p className="text-xs font-bold text-slate-light">Upload to active folder</p>
              <p className="text-[10px] text-slate-light/70 mt-1">Supports md, code, text, etc</p>
            </div>
            <input 
              type="file" 
              className="hidden" 
              ref={fileInputRef} 
              onChange={handleFileUpload} 
              disabled={uploading}
            />
          </div>

          {uploading && <div className="text-xs text-slate-light font-bold text-center animate-pulse">Uploading...</div>}

          {/* New Folder Inline Form */}
          {showNewFolderInput && (
            <div className="bg-bg-slate border border-tab-blue/40 rounded-lg p-3 animate-in fade-in zoom-in-95 duration-150">
              <p className="text-[10px] font-sans text-slate-light mb-2 font-bold uppercase tracking-wider">Create New Folder</p>
              <div className="flex gap-2">
                <input 
                  type="text"
                  placeholder="Folder name..."
                  value={newFolderName}
                  onChange={e => setNewFolderName(e.target.value)}
                  className="bg-bg-dark-slate border border-tab-blue/40 text-xs font-sans text-slate-light px-2.5 py-1.5 rounded flex-1 focus:outline-none focus:border-[#f1f5f9]"
                  onKeyDown={e => {
                    if (e.key === 'Enter') handleCreateFolder();
                    if (e.key === 'Escape') setShowNewFolderInput(false);
                  }}
                  autoFocus
                />
                <button 
                  onClick={handleCreateFolder}
                  className="px-3 py-1 bg-tab-blue text-text-black border border-tab-blue hover:bg-[#60a5fa] text-xs font-bold rounded cursor-pointer transition-colors"
                >
                  OK
                </button>
                <button 
                  onClick={() => setShowNewFolderInput(false)}
                  className="px-2 py-1 bg-bg-dark-slate text-slate-light/70 hover:bg-bg-dark-slate hover:text-slate-light text-xs rounded cursor-pointer transition-all border border-tab-blue/30"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* File Explorer Workspace System */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="flex justify-between items-center mb-2 shrink-0">
              <h4 className="text-[10px] font-sans text-slate-light/70 tracking-wider uppercase font-bold">Workspace Explorer</h4>
              <div className="flex items-center gap-1.5">
                <button 
                  onClick={() => setShowNewFolderInput(true)}
                  className="flex items-center gap-1 text-[9px] px-2 py-0.5 bg-tab-blue text-text-black border border-tab-blue hover:bg-[#60a5fa] rounded uppercase cursor-pointer transition-all font-bold shadow-[0_0_6px_rgba(59,130,246,0.3)]"
                  title="Create Subfolder"
                >
                  <FolderPlus className="w-3 h-3" /> +Folder
                </button>
                <button 
                  onClick={() => {
                    setPreviewContent({ name: 'untitled.txt', content: '', isNew: true });
                    setIsFocused(true);
                  }}
                  className="flex items-center gap-1 text-[9px] px-2 py-0.5 bg-[#f1f5f9] text-text-black border border-[#f1f5f9] hover:bg-[#ffffff] rounded uppercase cursor-pointer transition-all font-bold shadow-[0_0_6px_rgba(241,245,249,0.3)]"
                  title="Create Text/Markdown File"
                >
                  <Plus className="w-3 h-3" /> +File
                </button>
              </div>
            </div>

            {/* Folder browser */}
            <div className="flex-1 overflow-y-auto pr-1">
              <div className="space-y-1.5">
                {/* Back up directory */}
                {currentPath && (
                  <div 
                    onClick={() => {
                      const parent = segments.slice(0, -1).join('/');
                      fetchFiles(parent);
                    }}
                    className="flex items-center gap-2.5 p-1.5 rounded-lg border border-transparent hover:bg-bg-slate cursor-pointer text-slate-light/70 hover:text-slate-light transition-all text-xs font-sans select-none"
                  >
                    <CornerLeftUp className="w-3.5 h-3.5 text-slate-light shrink-0" />
                    <span>.. / Up One Dir</span>
                  </div>
                )}

                {files.length === 0 && !currentPath ? (
                  <div className="flex justify-center items-center py-12 text-xs text-slate-light/40 font-sans">No files in workspace root</div>
                ) : files.length === 0 && currentPath ? (
                  <div className="flex justify-center items-center py-12 text-xs text-slate-light/40 font-sans">This folder is empty</div>
                ) : (
                  files.map(file => {
                    const isDir = file.isDirectory;
                    return (
                      <div 
                        key={file.path} 
                        className={`flex items-center justify-between p-2 rounded-lg bg-bg-slate/40 border transition-all group ${
                          isDir 
                            ? 'border-tab-blue/40 hover:border-tab-blue hover:bg-bg-slate' 
                            : 'border-tab-blue/20 hover:border-[#f1f5f9]/50 hover:bg-bg-slate'
                        }`}
                      >
                        <div 
                          className="flex items-center gap-2 overflow-hidden cursor-pointer flex-1 select-none"
                          onClick={() => {
                            if (isDir) {
                              fetchFiles(file.path);
                            } else {
                              handlePreview(file.path);
                            }
                          }}
                        >
                          {isDir ? (
                            <Folder className="w-4 h-4 text-tab-blue shrink-0" />
                          ) : (
                            <FileText className="w-4 h-4 text-slate-light shrink-0" />
                          )}
                          <div className="truncate">
                            <p className={`text-xs truncate ${isDir ? 'text-slate-light group-hover:text-amber-200 font-bold' : 'text-slate-light group-hover:text-amber-100'}`}>
                              {file.name}
                            </p>
                            {!isDir && (
                              <p className="text-[9px] text-slate-light/50 font-mono">{(file.size / 1024).toFixed(1)} KB</p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          {/* File analyze shortcut */}
                          {!isDir && onAnalyzeRequest && (
                            <button 
                              onClick={() => onAnalyzeRequest(file.path)}
                              className="p-1 opacity-0 group-hover:opacity-100 hover:bg-tab-blue/40 text-slate-light rounded transition-all"
                              title="Ask J.A.R.V.I.S. to analyze"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button 
                            onClick={(e) => { e.stopPropagation(); handleDelete(file.path); }}
                            className="p-1 opacity-0 group-hover:opacity-100 hover:bg-red-900/60 hover:text-red-200 text-slate-light/50 rounded transition-all"
                            title={isDir ? "Delete folder recursively" : "Delete file"}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
