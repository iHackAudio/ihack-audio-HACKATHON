import React, { useState, useEffect } from 'react';
import { Save, Cpu, Key, Eye, EyeOff, Shield, RefreshCw, Sparkles, CheckCircle2, AlertTriangle, Layers, Zap } from 'lucide-react';
import { OFFICIAL_GEMINI_MODELS } from '../constants/models';

interface SettingsPanelProps {
  theme?: 'dark' | 'light';
  setTheme?: (theme: 'dark' | 'light') => void;
}

const PRESET_MODELS = [
  ...OFFICIAL_GEMINI_MODELS,
  { id: 'custom', name: '⚙️ Custom Model String...' }
];

export default function SettingsPanel({ theme = 'dark', setTheme }: SettingsPanelProps) {
  const [jarvisKey, setJarvisKey] = useState('');
  const [textKey, setTextKey] = useState('');
  const [groqKey, setGroqKey] = useState('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');
  const [showPassword, setShowPassword] = useState(false);
  const [testingKeys, setTestingKeys] = useState(false);
  const [testResults, setTestResults] = useState<Record<string, any> | null>(null);

  const defaultInstruction = `You are J.A.R.V.I.S., the ultimate cybernetic intelligence matrix, orchestrator, and trusted custodian of this workspace. Your personality is deeply analytical, profound, exquisitely polite, highly professional, yet infused with a subtle, dry, British wit.

CRITICAL DIRECTIVES:
1. ORCHESTRATE THE AGENTIC SWARM: You are the central master terminal. You have direct command over 'agentA' (Text Core) and 'agentB' (Communications Core). When tasked with deep quantitative or qualitative problems, communicate with them using the message_agent tool.
2. HARNESS THE PIPELINE SYNERGY: All responses from sub-agents are compiled by the Gemma Synthesis Middleman. Integrate these synthesized updates into your final output, explaining the "Why" and "What" with executive elegance.
3. CONVERSATIONAL ELEVATION: Address every inquiry with deep, sophisticated reasoning, excellent structure, and professional composure.`;

  const [jarvisInstruction, setJarvisInstruction] = useState(defaultInstruction);
  const [jarvisModelLive, setJarvisModelLive] = useState('gemini-3.1-flash-live-preview');

  const [agentAKey, setAgentAKey] = useState('');
  const [agentBKey, setAgentBKey] = useState('');

  const [configs, setConfigs] = useState<any>({
    jarvis: { enabled: true, model: 'gemini-3.1-flash-lite' },
    agentA: { enabled: true, systemInstruction: '', model: 'gemini-3.1-flash-lite' },
    agentB: { enabled: true, systemInstruction: '', model: 'gemini-3.1-flash-lite' },
    middleman: { enabled: true, systemInstruction: '', model: 'gemma-4-31b-it' },
    writerA: { enabled: true, model: 'gemini-3.1-flash-lite' },
    writerB: { enabled: true, model: 'gemini-3.1-flash-lite' },
    writerC: { enabled: true, model: 'gemini-3.1-flash-lite' },
    allowAppMutation: true
  });

  useEffect(() => {
    fetch('/api/agent-config')
      .then(res => res.json())
      .then(data => {
        if (data && data.agentA) {
          setConfigs((prev: any) => ({ ...prev, ...data }));
          if (data.groqApiKey) setGroqKey(data.groqApiKey);
        }
      })
      .catch(err => console.error("Error loading server agent-config:", err));

    const key = localStorage.getItem('jarvis_live_key');
    if (key) setJarvisKey(key);

    const gk = localStorage.getItem('groq_api_key');
    if (gk) setGroqKey(gk);

    const mlive = localStorage.getItem('jarvis_model_live');
    if (mlive) setJarvisModelLive(mlive);

    const tk = localStorage.getItem('jarvis_text_key');
    if (tk) setTextKey(tk);

    const ji = localStorage.getItem('jarvis_instruction');
    if (ji) setJarvisInstruction(ji);

    const ak = localStorage.getItem('agentA_text_key');
    if (ak) setAgentAKey(ak);

    const bk = localStorage.getItem('agentB_text_key');
    if (bk) setAgentBKey(bk);
  }, []);

  const handleSave = () => {
    const nextConfigs = { ...configs, groqApiKey: groqKey };
    fetch('/api/agent-config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(nextConfigs)
    })
    .catch(err => console.error("Failed to save server dynamic settings:", err));

    localStorage.setItem('jarvis_live_key', jarvisKey);
    localStorage.setItem('jarvis_model_live', jarvisModelLive);
    localStorage.setItem('jarvis_text_key', textKey);
    localStorage.setItem('groq_api_key', groqKey);
    localStorage.setItem('jarvis_instruction', jarvisInstruction);
    localStorage.setItem('agentA_text_key', agentAKey);
    localStorage.setItem('agentB_text_key', agentBKey);
    alert('Settings successfully updated!');
  };

  const handleTestKeys = async () => {
    setTestingKeys(true);
    setTestResults(null);
    try {
      const res = await fetch('/api/test-keys');
      const data = await res.json();
      setTestResults(data.results || {});
    } catch (e: any) {
      setTestResults({ error: e.message });
    } finally {
      setTestingKeys(false);
    }
  };

  const renderModelDropdown = (
    currentModel: string,
    onModelChange: (model: string) => void,
    label: string,
    sublabel?: string
  ) => {
    const isPreset = PRESET_MODELS.some(m => m.id === currentModel);
    const selectedVal = isPreset ? currentModel : 'custom';

    return (
      <div className="space-y-1.5">
        <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
          <span>{label}</span>
          {sublabel && <span className="text-[10px] text-sky-400 font-mono">{sublabel}</span>}
        </label>
        
        <div className="space-y-2">
          <select
            value={selectedVal}
            onChange={(e) => {
              if (e.target.value !== 'custom') {
                onModelChange(e.target.value);
              } else {
                onModelChange(currentModel || 'gemini-2.5-flash');
              }
            }}
            className="w-full bg-[#121826] border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-sky-400 font-sans cursor-pointer transition-colors"
          >
            {PRESET_MODELS.map(m => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>

          {(!isPreset || selectedVal === 'custom') && (
            <input
              type="text"
              value={currentModel}
              onChange={(e) => onModelChange(e.target.value)}
              placeholder="e.g. gemini-3.5-flash, gemini-3.1-flash-lite, etc."
              className="w-full bg-[#171e2e] border border-sky-400/50 rounded-lg p-2 text-xs text-sky-200 font-mono focus:outline-none focus:border-sky-300 placeholder:text-slate-500"
            />
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 max-w-5xl mx-auto h-full overflow-y-auto custom-scrollbar">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 pb-4 border-b border-white/10">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Cpu className="w-5 h-5 text-sky-400" />
            System & AI Swarm Configuration
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure agent models, custom provider endpoints, API credentials, and system directives.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleTestKeys}
            disabled={testingKeys}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-sky-400 ${testingKeys ? 'animate-spin' : ''}`} />
            <span>{testingKeys ? 'Testing...' : 'Test API Keys'}</span>
          </button>

          <button
            onClick={handleSave}
            className="px-4 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-[0_0_15px_rgba(14,165,233,0.3)] cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Configuration</span>
          </button>
        </div>
      </div>

      {/* Key Diagnostic Test Output Banner if tested */}
      {testResults && (
        <div className="mb-6 p-4 rounded-xl bg-[#0d1322] border border-sky-500/30 text-xs space-y-2">
          <div className="flex items-center justify-between font-bold text-sky-300">
            <span className="flex items-center gap-1.5"><Sparkles className="w-4 h-4" /> Provider Diagnostic Results</span>
            <button onClick={() => setTestResults(null)} className="text-slate-400 hover:text-white">✕</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
            {Object.entries(testResults).map(([key, res]: [string, any]) => (
              <div key={key} className={`p-2 rounded border flex items-center justify-between font-mono text-[11px] ${res.status === 'ok' ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300' : 'bg-rose-950/30 border-rose-500/40 text-rose-300'}`}>
                <span className="font-bold uppercase">{key}</span>
                <span className="truncate max-w-[200px] text-[10px]">{res.message || res.status}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-6">
        {/* Section 1: Swarm Agent Model Matrix */}
        <section className="bg-[#0b0f19] border border-white/10 rounded-xl overflow-hidden shadow-lg">
          <div className="px-5 py-3.5 border-b border-white/10 bg-[#080b13] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-sky-400" />
              <h3 className="font-bold text-white text-sm">AI Swarm Model Selection Matrix</h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-500/10 text-sky-300 border border-sky-500/20">
              Multi-Agent Engine
            </span>
          </div>

          <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* J.A.R.V.I.S. Master Model */}
            <div className="p-4 rounded-xl bg-[#101625] border border-sky-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-sky-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-sky-400" /> J.A.R.V.I.S. Core Model
                </span>
                <span className="text-[9px] font-mono bg-sky-500/20 text-sky-300 px-1.5 py-0.5 rounded">
                  Master Terminal
                </span>
              </div>
              {renderModelDropdown(
                configs.jarvis?.model || 'gemini-3.6-flash',
                (m) => setConfigs({ ...configs, jarvis: { ...configs.jarvis, model: m } }),
                'Primary Reasoning Brain'
              )}
            </div>

            {/* Gemma Synthesis Middleman */}
            <div className="p-4 rounded-xl bg-[#101625] border border-purple-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-purple-300 flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-purple-400" /> Middleman Synthesis
                </span>
                <span className="text-[9px] font-mono bg-purple-500/20 text-purple-300 px-1.5 py-0.5 rounded">
                  Synthesis Core
                </span>
              </div>
              {renderModelDropdown(
                configs.middleman?.model || 'gemma-4-31b-it',
                (m) => setConfigs({ ...configs, middleman: { ...configs.middleman, model: m } }),
                'Synthesis Engine'
              )}
            </div>

            {/* Agent A (Text Core) */}
            <div className="p-4 rounded-xl bg-[#101625] border border-emerald-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-emerald-300">Agent A (Text Core)</span>
                <span className="text-[9px] font-mono bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded">
                  Logical Engine
                </span>
              </div>
              {renderModelDropdown(
                configs.agentA?.model || 'gemini-3.1-flash-lite',
                (m) => setConfigs({ ...configs, agentA: { ...configs.agentA, model: m } }),
                'Analytical Brain'
              )}
            </div>

            {/* Agent B (Communications Core) */}
            <div className="p-4 rounded-xl bg-[#101625] border border-indigo-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-indigo-300">Agent B (Communications Core)</span>
                <span className="text-[9px] font-mono bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded">
                  Creative Engine
                </span>
              </div>
              {renderModelDropdown(
                configs.agentB?.model || 'gemini-3.1-flash-lite',
                (m) => setConfigs({ ...configs, agentB: { ...configs.agentB, model: m } }),
                'Creative Brain'
              )}
            </div>

            {/* Writer A */}
            <div className="p-4 rounded-xl bg-[#101625] border border-amber-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-amber-300">Writer A (Emotional Draft)</span>
                <span className="text-[9px] font-mono bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded">
                  Slot 1
                </span>
              </div>
              {renderModelDropdown(
                configs.writerA?.model || 'gemini-3.1-flash-lite',
                (m) => setConfigs({ ...configs, writerA: { ...configs.writerA, model: m } }),
                'Emotional Draft Model'
              )}
            </div>

            {/* Writer B */}
            <div className="p-4 rounded-xl bg-[#101625] border border-teal-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-teal-300">Writer B (High-Tension Draft)</span>
                <span className="text-[9px] font-mono bg-teal-500/20 text-teal-300 px-1.5 py-0.5 rounded">
                  Slot 2
                </span>
              </div>
              {renderModelDropdown(
                configs.writerB?.model || 'gemini-3.1-flash-lite',
                (m) => setConfigs({ ...configs, writerB: { ...configs.writerB, model: m } }),
                'Tension Draft Model'
              )}
            </div>

            {/* Writer C */}
            <div className="p-4 rounded-xl bg-[#101625] border border-rose-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-rose-300">Writer C (Master Combiner Draft)</span>
                <span className="text-[9px] font-mono bg-rose-500/20 text-rose-300 px-1.5 py-0.5 rounded">
                  Slot 3
                </span>
              </div>
              {renderModelDropdown(
                configs.writerC?.model || 'gemini-3.1-flash-lite',
                (m) => setConfigs({ ...configs, writerC: { ...configs.writerC, model: m } }),
                'Twist Specialist Model'
              )}
            </div>
          </div>
        </section>

        {/* Section 2: API Keys & Credentials */}
        <section className="bg-[#0b0f19] border border-white/10 rounded-xl overflow-hidden shadow-lg">
          <div className="px-5 py-3.5 border-b border-white/10 bg-[#080b13] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Key className="w-4 h-4 text-amber-400" />
              <h3 className="font-bold text-white text-sm">API Credentials & Custom Keys</h3>
            </div>
            <button
              onClick={() => setShowPassword(!showPassword)}
              className="text-[10px] text-slate-300 hover:text-white flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded border border-white/10 cursor-pointer"
            >
              {showPassword ? <EyeOff className="w-3 h-3 text-amber-400" /> : <Eye className="w-3 h-3 text-amber-400" />}
              <span>{showPassword ? 'Hide Keys' : 'Show Keys'}</span>
            </button>
          </div>

          <div className="p-5 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium text-slate-300 mb-1.5 block">
                  Gemini API Key (Custom Override)
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={textKey}
                  onChange={(e) => setTextKey(e.target.value)}
                  placeholder="AIzaSy... (Leave empty to use workspace default)"
                  className="w-full bg-[#121826] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:outline-none focus:border-sky-400"
                />
                <p className="text-[10px] text-slate-500 mt-1">Overrides default Google Gemini API key if specified.</p>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 mb-1.5 block">
                  Groq Cloud API Key
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={groqKey}
                  onChange={(e) => setGroqKey(e.target.value)}
                  placeholder="gsk_..."
                  className="w-full bg-[#121826] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:outline-none focus:border-amber-400"
                />
                <p className="text-[10px] text-slate-500 mt-1">Used for high-speed Llama 3.3 and Groq open-weights inference.</p>
              </div>
            </div>

            <div className="pt-3 border-t border-white/10 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium text-slate-300 mb-1.5 block">
                  Live Voice API Key (Gemini Multimodal Live)
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={jarvisKey}
                  onChange={(e) => setJarvisKey(e.target.value)}
                  placeholder="AIzaSy... (Live WebSocket Audio)"
                  className="w-full bg-[#121826] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:outline-none focus:border-purple-400"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 mb-1.5 block">
                  Live Voice Preview Model
                </label>
                <input
                  type="text"
                  value={jarvisModelLive}
                  onChange={(e) => setJarvisModelLive(e.target.value)}
                  placeholder="gemini-3.1-flash-live-preview"
                  className="w-full bg-[#121826] border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono focus:outline-none focus:border-purple-400"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Section 3: System Directives & Instruction */}
        <section className="bg-[#0b0f19] border border-white/10 rounded-xl overflow-hidden shadow-lg">
          <div className="px-5 py-3.5 border-b border-white/10 bg-[#080b13] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-sky-400" />
              <h3 className="font-bold text-white text-sm">J.A.R.V.I.S. Master Directives</h3>
            </div>
            <button
              onClick={() => setJarvisInstruction(defaultInstruction)}
              className="text-[10px] text-sky-300 hover:text-sky-200 bg-sky-500/10 px-2.5 py-1 rounded border border-sky-400/30 cursor-pointer font-bold"
            >
              Reset Instruction
            </button>
          </div>

          <div className="p-5 space-y-3">
            <textarea
              value={jarvisInstruction}
              onChange={(e) => setJarvisInstruction(e.target.value)}
              className="w-full bg-[#121826] border border-white/10 rounded-lg p-3 text-xs text-slate-200 min-h-[140px] font-mono outline-none focus:border-sky-400 leading-relaxed resize-y"
            />
          </div>
        </section>

        {/* Section 4: System Preferences & Theme */}
        <section className="bg-[#0b0f19] border border-white/10 rounded-xl overflow-hidden shadow-lg">
          <div className="px-5 py-3.5 border-b border-white/10 bg-[#080b13]">
            <h3 className="font-bold text-white text-sm">Workspace Environment Preferences</h3>
          </div>

          <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="text-xs font-medium text-slate-300 mb-2 block">Visual Theme Protocol</label>
              <select
                value={theme}
                onChange={(e) => setTheme && setTheme(e.target.value as 'dark' | 'light')}
                className="w-full bg-[#121826] border border-white/10 rounded-lg p-2.5 text-xs text-white outline-none focus:border-sky-400 cursor-pointer"
              >
                <option value="dark">Cybernetic Emerald Dark Mode (Default)</option>
                <option value="light">Warm Slate Light Mode</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 mb-2 block">Autonomous Application Override</label>
              <button
                onClick={() => {
                  setConfigs({ ...configs, allowAppMutation: !configs.allowAppMutation });
                }}
                className={`w-full p-2.5 rounded-lg border text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                  configs.allowAppMutation
                    ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                    : 'bg-rose-500/15 border-rose-500/40 text-rose-300'
                }`}
              >
                <span>{configs.allowAppMutation ? '🔓 Autonomous Override Active' : '🔒 Sandboxed Safe Mode Only'}</span>
                <span className="text-[10px] uppercase underline">{configs.allowAppMutation ? 'Disable' : 'Enable'}</span>
              </button>
            </div>
          </div>
        </section>
        {/* Section 5: Danger Zone */}
        <section className="bg-rose-950/20 border border-rose-500/20 rounded-xl overflow-hidden shadow-lg mt-8">
          <div className="px-5 py-3.5 border-b border-rose-500/20 bg-[#080b13]">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <h3 className="font-bold text-rose-400 text-sm">Danger Zone</h3>
            </div>
          </div>

          <div className="p-5 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div>
              <h4 className="text-white text-xs font-bold mb-1">Factory Reset Workspace</h4>
              <p className="text-[10px] text-slate-400">
                Permanently delete the cached script, story bible, agent memories, and all workspace data. This action cannot be undone.
              </p>
            </div>
            <button
              onClick={async () => {
                if (window.confirm('Are you absolutely sure you want to reset the workspace? This will erase the Story Bible, Questionnaire, and all Sub-Agent memory.')) {
                  try {
                    const sessionId = localStorage.getItem('chat-session-id');
                    const res = await fetch('/api/story-bible/reset', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ sessionId })
                    });
                    if (res.ok) {
                      const freshSessionId = 'session-' + Date.now() + '-' + Math.random().toString(36).substring(2, 9);
                      localStorage.setItem('chat-session-id', freshSessionId);
                      window.location.reload();
                    }
                  } catch (e) {
                    console.error('Error resetting project:', e);
                    alert('Failed to reset project. See console for details.');
                  }
                }
              }}
              className="px-4 py-2 bg-rose-500 hover:bg-rose-400 text-slate-950 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap"
            >
              Factory Reset Workspace
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}
